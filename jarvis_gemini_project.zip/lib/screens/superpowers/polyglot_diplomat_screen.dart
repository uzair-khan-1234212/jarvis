import 'package:flutter/material.dart';
import '../../services/gemini_ai_service.dart';
import '../../services/voice_service.dart';

class PolyglotDiplomatScreen extends StatefulWidget {
  final GeminiAiService aiService;
  final VoiceService voiceService;

  const PolyglotDiplomatScreen({
    super.key,
    required this.aiService,
    required this.voiceService,
  });

  @override
  State<PolyglotDiplomatScreen> createState() => _PolyglotDiplomatScreenState();
}

class _PolyglotDiplomatScreenState extends State<PolyglotDiplomatScreen> {
  static const List<String> _languages = [
    'English',
    'Urdu',
    'Arabic',
    'Hindi',
    'Spanish',
    'French',
    'German',
    'Mandarin Chinese',
    'Japanese',
    'Russian',
    'Portuguese',
    'Italian',
    'Turkish',
    'Korean',
  ];

  String _sourceLang = 'English';
  String _targetLang = 'Urdu';
  final TextEditingController _inputCtrl = TextEditingController();
  String _translatedOutput = '';
  bool _translating = false;

  void _swapLanguages() {
    setState(() {
      final tmp = _sourceLang;
      _sourceLang = _targetLang;
      _targetLang = tmp;
    });
  }

  Future<void> _translateNow() async {
    if (_inputCtrl.text.trim().isEmpty) return;
    setState(() => _translating = true);
    final prompt = '''
You are the J.A.R.V.I.S. Polyglot Diplomat. Translate the following text from $_sourceLang into culturally nuanced, polite $_targetLang.
Provide the native script translation followed by phonetic pronunciation in parentheses.

Input ($_sourceLang): "${_inputCtrl.text.trim()}"
''';
    final res = await widget.aiService.generateSingleCompletion(prompt: prompt);
    if (mounted) {
      setState(() {
        _translating = false;
        _translatedOutput = res;
      });
      widget.voiceService.speak(res);
    }
  }

  @override
  Widget build(BuildContext context) {
    const cyan = Color(0xFF00E5FF);
    return Scaffold(
      backgroundColor: const Color(0xFF050A14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A1426),
        title: const Text(
          '🌐 POLYGLOT DIPLOMAT (14+ LANGUAGES)',
          style: TextStyle(color: cyan, fontSize: 14, fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: _langDropdown(_sourceLang, (v) => setState(() => _sourceLang = v!))),
                IconButton(
                  onPressed: _swapLanguages,
                  icon: const Icon(Icons.swap_horiz, color: cyan, size: 28),
                ),
                Expanded(child: _langDropdown(_targetLang, (v) => setState(() => _targetLang = v!))),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _inputCtrl,
              maxLines: 3,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Source Speech / Text ($_sourceLang)',
                labelStyle: const TextStyle(color: Colors.white70),
                filled: true,
                fillColor: const Color(0xFF0C172B),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: cyan,
                  foregroundColor: Colors.black,
                ),
                onPressed: _translating ? null : _translateNow,
                icon: const Icon(Icons.translate),
                label: Text(_translating ? 'TRANSLATING...' : 'TRANSLATE & SPEAK ALOUD'),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF0C172B),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF00E676).withOpacity(0.6)),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    _translatedOutput.isEmpty
                        ? 'Diplomatic translation card standing by...'
                        : _translatedOutput,
                    style: const TextStyle(color: Colors.white, fontSize: 16, height: 1.5),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _langDropdown(String current, ValueChanged<String?> onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0C172B),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.5)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: current,
          dropdownColor: const Color(0xFF0C172B),
          style: const TextStyle(color: Colors.white, fontSize: 13),
          isExpanded: true,
          items: _languages
              .map((l) => DropdownMenuItem(value: l, child: Text(l)))
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}
