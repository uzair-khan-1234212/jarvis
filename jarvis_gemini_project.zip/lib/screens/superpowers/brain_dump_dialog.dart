import 'package:flutter/material.dart';
import '../../services/task_executor_service.dart';
import '../../services/voice_service.dart';

class BrainDumpDialog extends StatefulWidget {
  final TaskExecutorService taskExecutor;
  final VoiceService voiceService;

  const BrainDumpDialog({
    super.key,
    required this.taskExecutor,
    required this.voiceService,
  });

  @override
  State<BrainDumpDialog> createState() => _BrainDumpDialogState();
}

class _BrainDumpDialogState extends State<BrainDumpDialog> {
  final TextEditingController _inputCtrl = TextEditingController(
    text:
        "Remind me to call Jack at 4pm, draft a WhatsApp to Sarah saying I'm 15 mins late, calculate 25% of 600, add milk and eggs to my todo, and turn on the flashlight",
  );
  List<BrainDumpTaskItem> _tasks = [];
  String _executiveBriefing = '';
  bool _isExecuting = false;

  Future<void> _runDecoupler() async {
    if (_inputCtrl.text.trim().isEmpty) return;
    setState(() {
      _isExecuting = true;
      _executiveBriefing = '';
    });

    final res = await widget.taskExecutor.executeBrainDump(
      compoundPrompt: _inputCtrl.text.trim(),
      onProgress: (updated) {
        if (mounted) {
          setState(() => _tasks = List.from(updated));
        }
      },
    );

    if (mounted) {
      setState(() {
        _isExecuting = false;
        _executiveBriefing = res['briefing']?.toString() ?? '';
      });
      if (_executiveBriefing.isNotEmpty) {
        widget.voiceService.speak(_executiveBriefing);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    const violet = Color(0xFFBA68C8);
    return Dialog(
      backgroundColor: const Color(0xFF091224),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: violet, width: 1.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.hub_outlined, color: violet),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '🧠 CHAOTIC BRAIN DUMP DECOUPLER',
                      style: TextStyle(
                        color: violet,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        letterSpacing: 1.1,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              const Text(
                'Dictate or type 4–5 unrelated tasks in a single breath. Gemini decouples and executes them in parallel async futures.',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _inputCtrl,
                maxLines: 3,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xFF050A14),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: violet,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: _isExecuting ? null : _runDecoupler,
                  icon: const Icon(Icons.bolt),
                  label: Text(_isExecuting
                      ? 'DECOUPLING & EXECUTING VECTORS...'
                      : 'DISPATCH PARALLEL EXECUTION'),
                ),
              ),
              if (_tasks.isNotEmpty) ...[
                const SizedBox(height: 14),
                for (final t in _tasks)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0E1B33),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: t.status == 'COMPLETED'
                            ? const Color(0xFF00E676)
                            : const Color(0xFFFFB300),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          t.status == 'COMPLETED'
                              ? Icons.check_circle
                              : Icons.autorenew,
                          color: t.status == 'COMPLETED'
                              ? const Color(0xFF00E676)
                              : const Color(0xFFFFB300),
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '[${t.category}] ${t.description}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                t.resultSummary,
                                style: const TextStyle(
                                  color: Color(0xFF00E5FF),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
              if (_executiveBriefing.isNotEmpty) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.black38,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFF00E5FF)),
                  ),
                  child: Text(
                    _executiveBriefing,
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
