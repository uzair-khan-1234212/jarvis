import 'package:flutter/material.dart';
import '../../services/gemini_ai_service.dart';
import '../../services/platform_bridge_service.dart';
import '../../services/voice_service.dart';

/// Superpower #1: Iron Man Zero-Touch Air Gestures Calibration Dialog
class AirGesturesModal extends StatefulWidget {
  final PlatformBridgeService bridge;
  final bool initialEnabled;
  final ValueChanged<bool> onChanged;

  const AirGesturesModal({
    super.key,
    required this.bridge,
    required this.initialEnabled,
    required this.onChanged,
  });

  @override
  State<AirGesturesModal> createState() => _AirGesturesModalState();
}

class _AirGesturesModalState extends State<AirGesturesModal> {
  late bool _enabled;

  @override
  void initState() {
    super.initState();
    _enabled = widget.initialEnabled;
  }

  Future<void> _toggle(bool val) async {
    await widget.bridge.setAirGestures(val);
    setState(() => _enabled = val);
    widget.onChanged(val);
  }

  @override
  Widget build(BuildContext context) {
    const cyan = Color(0xFF00E5FF);
    return AlertDialog(
      backgroundColor: const Color(0xFF081223),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: cyan),
      ),
      title: const Text(
        '🖐️ IRON MAN ZERO-TOUCH AIR GESTURES',
        style: TextStyle(color: cyan, fontSize: 14, fontWeight: FontWeight.bold),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            activeColor: const Color(0xFF00E676),
            title: const Text('Optical Proximity Sensor Hook', style: TextStyle(color: Colors.white)),
            value: _enabled,
            onChanged: _toggle,
          ),
          const Divider(color: Colors.white24),
          const Text('• 👋 Quick Wave (<0.8s): Next Media Track', style: TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 6),
          const Text('• ✋ Palm Hover (1–2s): Play / Pause Media', style: TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 6),
          const Text('• 👉 Double Wave: Trigger HUD Action', style: TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('CLOSE', style: TextStyle(color: cyan)),
        ),
      ],
    );
  }
}

/// Superpower #2: Arc Reactor Charging Telemetry Dialog
class ArcReactorTelemetryDialog extends StatelessWidget {
  final Map<String, dynamic> telemetry;

  const ArcReactorTelemetryDialog({super.key, required this.telemetry});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFFFB300);
    final watts = (telemetry['watts'] as num?)?.toStringAsFixed(1) ?? '18.5';
    final pct = telemetry['percentage'] ?? 82;
    final temp = telemetry['temperatureC'] ?? 31.4;
    final mv = telemetry['voltageMv'] ?? 4180;
    final medium = telemetry['medium'] ?? 'AC Turbo Flux';

    return AlertDialog(
      backgroundColor: const Color(0xFF081223),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: gold, width: 1.5),
      ),
      title: const Text(
        '⚡ ARC REACTOR CHARGING TELEMETRY',
        style: TextStyle(color: gold, fontSize: 14, fontWeight: FontWeight.bold),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Energy Intake: $watts Watts ($medium)', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Power Cells: $pct% Capacity', style: const TextStyle(color: Color(0xFF00E676))),
          Text('Core Bus Voltage: $mv mV', style: const TextStyle(color: Colors.white70)),
          Text('Thermal Grade: $temp °C (Nominal)', style: const TextStyle(color: Colors.white70)),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('ACKNOWLEDGE', style: TextStyle(color: gold)),
        ),
      ],
    );
  }
}

/// Superpower #5: Holographic Floating Co-Pilot On-Screen Triage Dialog
class FloatingCoPilotModal extends StatefulWidget {
  final PlatformBridgeService bridge;
  final GeminiAiService aiService;
  final VoiceService voiceService;

  const FloatingCoPilotModal({
    super.key,
    required this.bridge,
    required this.aiService,
    required this.voiceService,
  });

  @override
  State<FloatingCoPilotModal> createState() => _FloatingCoPilotModalState();
}

class _FloatingCoPilotModalState extends State<FloatingCoPilotModal> {
  String _triageResult = 'Inspecting foreground nodes & notifications...';

  @override
  void initState() {
    super.initState();
    _runContextTriage();
  }

  Future<void> _runContextTriage() async {
    final screenDump = await widget.bridge.dumpScreenTree();
    final prompt = '''
You are the J.A.R.V.I.S. Holographic Floating Co-Pilot.
Based on this foreground screen dump:
$screenDump

Provide:
1. 3 smart quick replies (Witty, Professional, Casual) if a chat/message is visible.
2. Any phishing/OTP security warnings or product pricing triage.
''';
    final res = await widget.aiService.generateSingleCompletion(prompt: prompt);
    if (mounted) {
      setState(() => _triageResult = res);
    }
  }

  @override
  Widget build(BuildContext context) {
    const cyan = Color(0xFF00E5FF);
    return AlertDialog(
      backgroundColor: const Color(0xFF081223),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: cyan),
      ),
      title: const Text(
        '👁️ HOLOGRAPHIC CO-PILOT CONTEXT TRIAGE',
        style: TextStyle(color: cyan, fontSize: 14, fontWeight: FontWeight.bold),
      ),
      content: SingleChildScrollView(
        child: Text(
          _triageResult,
          style: const TextStyle(color: Colors.white, fontSize: 12.5),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('CLOSE', style: TextStyle(color: cyan)),
        ),
      ],
    );
  }
}
