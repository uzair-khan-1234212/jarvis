import 'dart:io';
import 'package:flutter/material.dart';
import '../../services/voice_service.dart';

class NetworkAuditScreen extends StatefulWidget {
  final VoiceService voiceService;

  const NetworkAuditScreen({super.key, required this.voiceService});

  @override
  State<NetworkAuditScreen> createState() => _NetworkAuditScreenState();
}

class _NetworkAuditScreenState extends State<NetworkAuditScreen> {
  static const List<Map<String, dynamic>> _targetPorts = [
    {'port': 21, 'name': 'FTP File Transfer', 'risk': 'HIGH'},
    {'port': 22, 'name': 'SSH Secure Shell', 'risk': 'MEDIUM'},
    {'port': 23, 'name': 'Telnet Unencrypted', 'risk': 'CRITICAL'},
    {'port': 80, 'name': 'HTTP Web Admin', 'risk': 'LOW'},
    {'port': 443, 'name': 'HTTPS TLS Portal', 'risk': 'SAFE'},
    {'port': 554, 'name': 'RTSP IP Surveillance Camera', 'risk': 'HIGH'},
    {'port': 8080, 'name': 'HTTP Proxy / IoT Panel', 'risk': 'MEDIUM'},
  ];

  final TextEditingController _hostCtrl = TextEditingController(text: '192.168.1.1');
  List<Map<String, dynamic>> _results = [];
  int _securityScore = 100;
  bool _auditing = false;

  Future<void> _runNetworkAudit() async {
    setState(() {
      _auditing = true;
      _results = [];
      _securityScore = 100;
    });

    final host = _hostCtrl.text.trim();
    int score = 100;
    final found = <Map<String, dynamic>>[];

    for (final p in _targetPorts) {
      final port = p['port'] as int;
      bool isOpen = false;
      try {
        final socket = await Socket.connect(host, port, timeout: const Duration(milliseconds: 450));
        isOpen = true;
        socket.destroy();
      } catch (_) {
        isOpen = false;
      }
      if (isOpen) {
        if (p['risk'] == 'CRITICAL') score -= 35;
        if (p['risk'] == 'HIGH') score -= 20;
        if (p['risk'] == 'MEDIUM') score -= 10;
      }
      found.add({
        ...p,
        'open': isOpen,
      });
    }

    if (mounted) {
      setState(() {
        _auditing = false;
        _results = found;
        _securityScore = score.clamp(0, 100);
      });
      widget.voiceService.speak(
        'Stark network audit complete for $host, Sir. Overall network security score is $_securityScore out of 100.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    const cyan = Color(0xFF00E5FF);
    return Scaffold(
      backgroundColor: const Color(0xFF050A14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A1426),
        title: const Text(
          '🛡️ STARK NETWORK & PORT VULNERABILITY AUDIT',
          style: TextStyle(color: cyan, fontSize: 14, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _hostCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Target Gateway / Subnet Host IP',
                    labelStyle: const TextStyle(color: Colors.white70),
                    filled: true,
                    fillColor: const Color(0xFF0C172B),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: cyan,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
                onPressed: _auditing ? null : _runNetworkAudit,
                icon: const Icon(Icons.radar),
                label: Text(_auditing ? 'SWEEPING...' : 'AUDIT'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF0C172B),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: cyan),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'STARK DEFENSE SECURITY SCORE',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                Text(
                  '$_securityScore / 100',
                  style: TextStyle(
                    color: _securityScore >= 80 ? const Color(0xFF00E676) : const Color(0xFFFF1744),
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          for (final r in _results)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF0A1426),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: (r['open'] as bool)
                      ? const Color(0xFFFF1744)
                      : const Color(0xFF00E676).withOpacity(0.4),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'PORT ${r["port"]} — ${r["name"]}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                  Text(
                    (r['open'] as bool) ? 'OPEN (${r["risk"]})' : 'CLOSED / SECURE',
                    style: TextStyle(
                      color: (r['open'] as bool)
                          ? const Color(0xFFFF1744)
                          : const Color(0xFF00E676),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
