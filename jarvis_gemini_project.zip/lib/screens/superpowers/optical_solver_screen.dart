import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/gemini_ai_service.dart';
import '../../services/voice_service.dart';

class OpticalSolverScreen extends StatefulWidget {
  final GeminiAiService aiService;
  final VoiceService voiceService;

  const OpticalSolverScreen({
    super.key,
    required this.aiService,
    required this.voiceService,
  });

  @override
  State<OpticalSolverScreen> createState() => _OpticalSolverScreenState();
}

class _OpticalSolverScreenState extends State<OpticalSolverScreen> {
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _queryCtrl = TextEditingController();
  String _selectedMode = 'MATH'; // MATH, CODE, BILL, HARDWARE
  Uint8List? _capturedBytes;
  String _solutionMarkdown = '';
  bool _analyzing = false;

  Future<void> _captureAndSolve(ImageSource source) async {
    try {
      final file = await _picker.pickImage(source: source, imageQuality: 85);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      setState(() {
        _capturedBytes = bytes;
        _analyzing = true;
        _solutionMarkdown = 'Scanning optical target via Gemini Vision HUD...';
      });

      final answer = await widget.aiService.analyzeOpticalImage(
        imageBytes: bytes,
        solverMode: _selectedMode,
        customQuestion: _queryCtrl.text.trim(),
      );

      if (mounted) {
        setState(() {
          _analyzing = false;
          _solutionMarkdown = answer;
        });
        widget.voiceService.speak('Optical HUD analysis complete, Sir.');
      }
    } catch (e) {
      setState(() {
        _analyzing = false;
        _solutionMarkdown = 'Optical sensor error: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    const cyan = Color(0xFF00E5FF);
    return Scaffold(
      backgroundColor: const Color(0xFF050A14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A1426),
        title: const Text(
          '👁️ REAL-TIME OPTICAL HUD SOLVER (GEMINI VISION)',
          style: TextStyle(color: cyan, fontSize: 14, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _modeChip('MATH', '📐 Math & Physics'),
              _modeChip('CODE', '💻 Code Debugger'),
              _modeChip('BILL', '🧾 Bill & Receipt Splitter'),
              _modeChip('HARDWARE', '⚡ Electronics & IC Pinout'),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            height: 220,
            decoration: BoxDecoration(
              color: const Color(0xFF0B1528),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: cyan, width: 1.5),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                if (_capturedBytes != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.memory(_capturedBytes!, fit: BoxFit.cover, width: double.infinity),
                  )
                else
                  const Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.center_focus_strong, color: cyan, size: 54),
                      SizedBox(height: 8),
                      Text(
                        'TARGETING AR VIEWPORT READY',
                        style: TextStyle(color: cyan, letterSpacing: 1.4, fontSize: 12),
                      ),
                    ],
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _queryCtrl,
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Optional directive (e.g., "Split among 4 people with 20% tip")',
              hintStyle: const TextStyle(color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF0B1528),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: cyan,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: _analyzing ? null : () => _captureAndSolve(ImageSource.camera),
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('SCAN CAMERA'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: cyan,
                    side: const BorderSide(color: cyan),
                  ),
                  onPressed: _analyzing ? null : () => _captureAndSolve(ImageSource.gallery),
                  icon: const Icon(Icons.photo_library_outlined),
                  label: const Text('PICK IMAGE'),
                ),
              ),
            ],
          ),
          if (_solutionMarkdown.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF0B1528),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: cyan.withOpacity(0.45)),
              ),
              child: MarkdownBody(
                data: _solutionMarkdown,
                styleSheet: MarkdownStyleSheet(
                  p: const TextStyle(color: Colors.white, fontSize: 13),
                  h1: const TextStyle(color: cyan, fontWeight: FontWeight.bold),
                  h2: const TextStyle(color: cyan, fontWeight: FontWeight.bold),
                  code: const TextStyle(
                    color: Color(0xFF00E676),
                    backgroundColor: Colors.black54,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _modeChip(String id, String label) {
    final selected = _selectedMode == id;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      selectedColor: const Color(0xFF00E5FF),
      backgroundColor: const Color(0xFF0E1B33),
      labelStyle: TextStyle(
        color: selected ? Colors.black : Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      onSelected: (_) => setState(() => _selectedMode = id),
    );
  }
}
