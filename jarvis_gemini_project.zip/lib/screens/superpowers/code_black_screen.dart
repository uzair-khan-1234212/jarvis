import 'package:flutter/material.dart';
import '../../services/platform_bridge_service.dart';
import '../../services/voice_service.dart';

class CodeBlackScreen extends StatefulWidget {
  final PlatformBridgeService bridge;
  final VoiceService voiceService;

  const CodeBlackScreen({
    super.key,
    required this.bridge,
    required this.voiceService,
  });

  @override
  State<CodeBlackScreen> createState() => _CodeBlackScreenState();
}

class _CodeBlackScreenState extends State<CodeBlackScreen> {
  int _tamperViolations = 0;
  int _cornerTapCount = 0;
  DateTime _lastCornerTap = DateTime.now();

  void _onUnauthorizedTouch() {
    setState(() => _tamperViolations++);
    widget.bridge.triggerHapticAlarm();
    widget.voiceService.speak(
      'Tamper violation $_tamperViolations detected. Transmitting intruder biometrics to Defense Command.',
    );
  }

  void _onHiddenDisarmCornerTap() {
    final now = DateTime.now();
    if (now.difference(_lastCornerTap).inMilliseconds < 900) {
      _cornerTapCount++;
    } else {
      _cornerTapCount = 1;
    }
    _lastCornerTap = now;
    if (_cornerTapCount >= 4) {
      widget.voiceService.speak('Override Alpha verified. Code Black standing down, Sir.');
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    const crimson = Color(0xFFFF1744);
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _onUnauthorizedTouch,
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 36),
                    Container(
                      padding: const EdgeInsets.all(10),
                      color: crimson.withOpacity(0.2),
                      child: const Text(
                        '*** KERNEL PANIC — FATAL EXCEPTION: SIGSEGV AT 0xDEADBEEF ***',
                        style: TextStyle(
                          color: crimson,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'CPU 0: PID 1337 Comm: stark_sec_daemon Tainted: G   W   6.6.30-android15\n'
                      'Hardware name: STARK INDUSTRIES CYBERNETIC NODE\n'
                      'Call Trace:\n'
                      ' [<ffffffc0100894ac>] dump_backtrace+0x0/0x1a8\n'
                      ' [<ffffffc010891f20>] panic+0x14c/0x324\n'
                      ' [<ffffffc01024a00c>] die_kernel_fault+0x284/0x2c0\n'
                      ' [<ffffffc01009c114>] do_mem_abort+0x50/0xb8\n'
                      'Memory Segmentation Dump:\n'
                      '0xDEAD0000: 45 78 65 63 75 74 69 6e 67 20 43 6f 64 65 20 42\n'
                      '0xDEAD0010: 6c 61 63 6b 20 44 65 66 65 6e 73 65 20 4c 6f 63',
                      style: TextStyle(
                        color: Colors.greenAccent,
                        fontFamily: 'monospace',
                        fontSize: 11,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        border: Border.all(color: crimson, width: 2),
                        color: crimson.withOpacity(0.14),
                      ),
                      child: Text(
                        '🚨 TAMPER VIOLATIONS: [$_tamperViolations]
TRANSMITTING INTRUDER BIOMETRICS TO DEFENSE COMMAND',
                        style: const TextStyle(
                          color: crimson,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onLongPress: () {
                        widget.voiceService.speak('Emergency override accepted, Sir.');
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        alignment: Alignment.center,
                        child: const Text(
                          'SYSTEM HALTED — [LONG-PRESS BAR OR 4-TAP TOP-RIGHT TO DISARM]',
                          style: TextStyle(
                            color: Colors.white38,
                            fontFamily: 'monospace',
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Hidden 4-tap disarm target in top-right corner
              Positioned(
                top: 0,
                right: 0,
                width: 90,
                height: 90,
                child: GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: _onHiddenDisarmCornerTap,
                  child: const SizedBox.expand(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
