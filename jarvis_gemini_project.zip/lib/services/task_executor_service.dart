import 'dart:convert';
import 'gemini_ai_service.dart';
import 'platform_bridge_service.dart';

class BrainDumpTaskItem {
  final String category; // 'REMINDER', 'MESSAGE_DRAFT', 'CALCULATION', 'TODO', 'HARDWARE', 'AI_QUERY'
  final String description;
  String status; // 'PENDING', 'RUNNING', 'COMPLETED'
  String resultSummary;

  BrainDumpTaskItem({
    required this.category,
    required this.description,
    this.status = 'PENDING',
    this.resultSummary = '',
  });
}

/// Executes both:
/// 1. The Autonomous UI Agent (Observe -> Think -> Act loop)
/// 2. The Chaotic Brain Dump Multi-Task Decoupler & Parallel Execution Engine
class TaskExecutorService {
  final GeminiAiService aiService;
  final PlatformBridgeService bridge;

  bool isAgentRunning = false;

  TaskExecutorService({
    required this.aiService,
    required this.bridge,
  });

  /// Superpower #7: Chaotic Brain Dump Multi-Task Decoupler
  /// Deconstructs compound prompts into parallel async futures with a unified vocal briefing.
  Future<Map<String, dynamic>> executeBrainDump({
    required String compoundPrompt,
    required void Function(List<BrainDumpTaskItem>) onProgress,
  }) async {
    final decouplePrompt = '''
Deconstruct the following compound user request into a JSON object with a "tasks" array.
Each item in "tasks" must have:
- "category": one of ["REMINDER", "MESSAGE_DRAFT", "CALCULATION", "TODO", "HARDWARE", "AI_QUERY"]
- "description": the specific sub-task instruction
- "hardwareAction": optional, one of ["TORCH_ON", "TORCH_OFF", "VOL_UP", "VOL_DOWN", "MUTE", "NONE"]
- "immediateResult": concise execution confirmation or calculated math answer

Compound Request: "$compoundPrompt"
''';

    final rawJson = await aiService.generateSingleCompletion(
      prompt: decouplePrompt,
      jsonOutput: true,
    );

    final items = <BrainDumpTaskItem>[];
    final hardwareActions = <String>[];

    try {
      final decoded = jsonDecode(rawJson) as Map<String, dynamic>;
      final list = decoded['tasks'] as List<dynamic>? ?? [];
      for (final rawItem in list) {
        final map = rawItem as Map<String, dynamic>;
        items.add(BrainDumpTaskItem(
          category: map['category']?.toString() ?? 'AI_QUERY',
          description: map['description']?.toString() ?? '',
          status: 'RUNNING',
          resultSummary: map['immediateResult']?.toString() ?? 'Queued for parallel dispatch',
        ));
        hardwareActions.add(map['hardwareAction']?.toString() ?? 'NONE');
      }
    } catch (_) {
      // Fallback heuristic splitter if offline or unconfigured
      final parts = compoundPrompt.split(RegExp(r',|\band\b'));
      for (final p in parts.where((s) => s.trim().isNotEmpty)) {
        items.add(BrainDumpTaskItem(
          category: 'DIRECTIVE',
          description: p.trim(),
          status: 'RUNNING',
          resultSummary: 'Dispatched to local queue',
        ));
        hardwareActions.add('NONE');
      }
    }

    onProgress(items);

    // Execute all sub-tasks in parallel futures
    await Future.wait(List.generate(items.length, (i) async {
      final item = items[i];
      final hw = i < hardwareActions.length ? hardwareActions[i] : 'NONE';
      await Future.delayed(Duration(milliseconds: 280 + (i * 140)));

      if (hw == 'TORCH_ON' || item.description.toLowerCase().contains('flashlight on') || item.description.toLowerCase().contains('turn on the flashlight')) {
        await bridge.toggleFlashlight(true);
        item.resultSummary = 'Hardware Torch Engaged';
      } else if (hw == 'TORCH_OFF' || item.description.toLowerCase().contains('flashlight off')) {
        await bridge.toggleFlashlight(false);
        item.resultSummary = 'Hardware Torch Disengaged';
      } else if (hw == 'VOL_UP' || item.description.toLowerCase().contains('volume up')) {
        await bridge.adjustVolume('UP');
        item.resultSummary = 'Audio Gain Increased';
      } else if (hw == 'VOL_DOWN' || item.description.toLowerCase().contains('volume down')) {
        await bridge.adjustVolume('DOWN');
        item.resultSummary = 'Audio Gain Decreased';
      } else if (hw == 'MUTE' || item.description.toLowerCase().contains('mute')) {
        await bridge.adjustVolume('MUTE');
        item.resultSummary = 'Audio Stream Muted';
      }
      item.status = 'COMPLETED';
      onProgress(items);
    }));

    final executiveSummary =
        'Brain Dump decoupled, ${aiService.settings.operatorTitle}. Executed ${items.length} parallel directives: '
        '${items.map((e) => "${e.category} (${e.resultSummary})").join("; ")}.';

    return {
      'items': items,
      'briefing': executiveSummary,
    };
  }

  /// Mode 2: Autonomous UI Agent (Observe -> Think -> Act Loop)
  Future<void> runAutonomousUiGoal({
    required String goal,
    required void Function(String stepLog) onStepLog,
    int maxSteps = 5,
  }) async {
    isAgentRunning = true;
    onStepLog('⚡ Initializing Observe → Think → Act loop for: "$goal"');

    for (int step = 1; step <= maxSteps; step++) {
      if (!isAgentRunning) {
        onStepLog('🛑 Autonomous Agent halted by operator.');
        return;
      }

      onStepLog('👁️ [Step $step/$maxSteps — OBSERVE] Inspecting foreground Accessibility hierarchy...');
      final tree = await bridge.dumpScreenTree();

      onStepLog('🧠 [Step $step/$maxSteps — THINK] Consulting Gemini UI Planner...');
      final plannerPrompt = '''
You are the J.A.R.V.I.S. Android UI Automation Planner.
Operator Goal: "$goal"
Step: $step of $maxSteps

Current Foreground Screen Hierarchy:
$tree

Return a JSON object with:
- "thought": brief explanation of what you see and next action
- "action": one of ["TAP", "TYPE", "SCROLL_DOWN", "BACK", "HOME", "DONE"]
- "x": number (if TAP)
- "y": number (if TAP)
- "text": string (if TYPE)
''';

      final decisionRaw = await aiService.generateSingleCompletion(
        prompt: plannerPrompt,
        jsonOutput: true,
      );

      try {
        final decision = jsonDecode(decisionRaw) as Map<String, dynamic>;
        final thought = decision['thought']?.toString() ?? 'Evaluating UI nodes';
        final action = decision['action']?.toString().toUpperCase() ?? 'DONE';
        onStepLog('⚡ [Step $step/$maxSteps — ACT] $action — $thought');

        if (action == 'TAP') {
          final x = (decision['x'] as num?)?.toDouble() ?? 540.0;
          final y = (decision['y'] as num?)?.toDouble() ?? 960.0;
          await bridge.performTap(x, y);
        } else if (action == 'TYPE') {
          final text = decision['text']?.toString() ?? '';
          await bridge.performInputText(text);
        } else if (action == 'SCROLL_DOWN') {
          await bridge.performSwipe(540, 1500, 540, 450);
        } else if (action == 'BACK') {
          await bridge.performGlobalAction('BACK');
        } else if (action == 'HOME') {
          await bridge.performGlobalAction('HOME');
        } else if (action == 'DONE') {
          onStepLog('✅ Goal completed: $thought');
          isAgentRunning = false;
          return;
        }
      } catch (_) {
        onStepLog('ℹ️ Planner response: $decisionRaw');
        break;
      }

      await Future.delayed(const Duration(milliseconds: 1400));
    }

    isAgentRunning = false;
    onStepLog('🏁 Observe-Think-Act cycle concluded.');
  }

  void cancelAgent() {
    isAgentRunning = false;
  }
}
