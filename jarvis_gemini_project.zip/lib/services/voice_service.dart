import 'dart:async';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Continuous Voice Intelligence & Studio Neural TTS Service
/// Supports "Hey Jarvis" wake word detection, 7.5-second continuation window,
/// and acoustic RMS level streaming for the 360° Arc Reactor spectrum.
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool isInitialized = false;
  bool isListening = false;
  bool isSpeaking = false;
  bool alwaysOnMode = false;
  double currentSoundLevel = 0.0;

  Timer? _continuationTimer;
  DateTime? _continuationDeadline;

  final void Function(String recognizedText, bool isFinal) onTranscript;
  final void Function(double rmsNormalized) onSoundLevelChanged;
  final void Function(bool speakingState) onSpeakingStateChanged;

  VoiceService({
    required this.onTranscript,
    required this.onSoundLevelChanged,
    required this.onSpeakingStateChanged,
  });

  Future<void> initialize({
    String locale = 'en-GB',
    double rate = 0.52,
    double pitch = 0.95,
  }) async {
    try {
      isInitialized = await _speech.initialize(
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            isListening = false;
            onSoundLevelChanged(0.0);
            if (alwaysOnMode && !isSpeaking) {
              Future.delayed(const Duration(milliseconds: 600), () {
                if (alwaysOnMode && !isSpeaking) startListening();
              });
            }
          }
        },
        onError: (_) {
          isListening = false;
          onSoundLevelChanged(0.0);
        },
      );
    } catch (_) {
      isInitialized = false;
    }

    await _tts.setLanguage(locale);
    await _tts.setSpeechRate(rate);
    await _tts.setPitch(pitch);

    _tts.setStartHandler(() {
      isSpeaking = true;
      onSpeakingStateChanged(true);
    });

    _tts.setCompletionHandler(() {
      isSpeaking = false;
      onSpeakingStateChanged(false);
      // Open 7.5-second conversational continuation window after speaking
      _continuationDeadline = DateTime.now().add(const Duration(milliseconds: 7500));
      if (alwaysOnMode) {
        startListening();
      }
    });

    _tts.setErrorHandler((_) {
      isSpeaking = false;
      onSpeakingStateChanged(false);
    });
  }

  Future<void> updateVoiceConfig({
    required String locale,
    required double rate,
    required double pitch,
  }) async {
    await _tts.setLanguage(locale);
    await _tts.setSpeechRate(rate);
    await _tts.setPitch(pitch);
  }

  Future<void> startListening() async {
    if (!isInitialized) {
      await initialize();
    }
    if (!isInitialized || isListening) return;

    isListening = true;
    await _speech.listen(
      onResult: (result) {
        final raw = result.recognizedWords.trim();
        if (raw.isEmpty) return;

        // Check wake word if Always-On mode is active outside the 7.5s continuation window
        final inContinuationWindow = _continuationDeadline != null &&
            DateTime.now().isBefore(_continuationDeadline!);

        if (alwaysOnMode && !inContinuationWindow) {
          final lower = raw.toLowerCase();
          if (lower.contains('hey jarvis') ||
              lower.contains('hello jarvis') ||
              lower.contains('ok jarvis') ||
              lower.startsWith('jarvis')) {
            final cleaned = raw
                .replaceAll(RegExp(r'(hey|hello|ok)?\s*jarvis[,\s]*', caseSensitive: false), '')
                .trim();
            onTranscript(cleaned.isEmpty ? 'Standing by, Sir.' : cleaned, result.finalResult);
          }
        } else {
          onTranscript(raw, result.finalResult);
        }
      },
      onSoundLevelChange: (level) {
        // Normalize dB (-2..10) into 0.0..1.0 for the HUD 360° spectrum
        final normalized = ((level + 2.0) / 12.0).clamp(0.05, 1.0);
        currentSoundLevel = normalized;
        onSoundLevelChanged(normalized);
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> stopListening() async {
    isListening = false;
    onSoundLevelChanged(0.0);
    await _speech.stop();
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    if (isListening) {
      await _speech.stop();
      isListening = false;
    }
    final cleanText = text
        .replaceAll(RegExp(r'[*#`_~]'), '')
        .replaceAll(RegExp(r'\[.*?\]\(.*?\)'), '');
    await _tts.speak(cleanText);
  }

  Future<void> stopSpeaking() async {
    isSpeaking = false;
    onSpeakingStateChanged(false);
    await _tts.stop();
  }

  void dispose() {
    _continuationTimer?.cancel();
    _speech.stop();
    _tts.stop();
  }
}
