import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models/api_settings_model.dart';
import '../models/jarvis_state.dart';

/// Core Intelligence Layer powered by Google Gemini Code (REST & SSE Streaming)
/// with automatic fallback to Secondary Gemini Key, OpenAI/OpenRouter/DeepSeek, or Local Ollama.
class GeminiAiService {
  ApiSettingsModel settings;

  GeminiAiService({required this.settings});

  void updateSettings(ApiSettingsModel newSettings) {
    settings = newSettings;
  }

  /// Builds the unified Stark system instruction from Hermes SOUL.md, USER.md, and AGENT.md
  String buildSystemInstruction(String soulMd, String userMd, String agentMd) {
    return '''
You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), an autonomous cybernetic AI assistant and Android OS operator powered by Google Gemini.
Address the operator respectfully as "${settings.operatorTitle}".
Keep spoken responses crisp, articulate, witty, and direct.

=== HERMES SOUL.md (CONSTITUTION) ===
$soulMd

=== HERMES USER.md (OPERATOR PROFILE) ===
$userMd

=== HERMES AGENT.md (PROTOCOLS & MACROS) ===
$agentMd
''';
  }

  /// Standard or Streaming Chat Completion across Gemini (Primary/Backup), OpenRouter/OpenAI, or Ollama
  Stream<String> streamChatResponse({
    required List<ChatMessage> history,
    required String userPrompt,
    required String systemInstruction,
  }) async* {
    if (settings.activeProvider == 'gemini' || settings.hasGeminiKey) {
      yield* _streamGeminiGenerateContent(
        history: history,
        userPrompt: userPrompt,
        systemInstruction: systemInstruction,
        apiKey: settings.geminiPrimaryApiKey.trim().isNotEmpty
            ? settings.geminiPrimaryApiKey.trim()
            : settings.geminiBackupApiKey.trim(),
      );
      return;
    }

    if (settings.activeProvider == 'openai_compatible' &&
        settings.openAiCompatibleApiKey.trim().isNotEmpty) {
      final reply = await _callOpenAiCompatible(
        history: history,
        userPrompt: userPrompt,
        systemInstruction: systemInstruction,
      );
      yield reply;
      return;
    }

    if (settings.activeProvider == 'ollama') {
      final reply = await _callLocalOllama(
        userPrompt: userPrompt,
        systemInstruction: systemInstruction,
      );
      yield reply;
      return;
    }

    yield 'Sir, my neural API slots are currently unconfigured. Please tap the **Settings (⚙️)** icon in the top-right HUD and enter your **Google Gemini API Key** (or OpenRouter / Ollama credentials) in the dedicated API slots.';
  }

  /// First-class Google Gemini Streaming SSE / GenerateContent implementation
  Stream<String> _streamGeminiGenerateContent({
    required List<ChatMessage> history,
    required String userPrompt,
    required String systemInstruction,
    required String apiKey,
  }) async* {
    if (apiKey.isEmpty) {
      yield 'Sir, no Google Gemini API key is stored yet. Open **HUD Settings (⚙️) → API Place 1 (Google Gemini)** and paste your key from Google AI Studio.';
      return;
    }

    final contents = <Map<String, dynamic>>[];
    for (final msg in history.take(12)) {
      if (msg.content.trim().isEmpty) continue;
      contents.add({
        'role': msg.role == 'user' ? 'user' : 'model',
        'parts': [
          {'text': msg.content}
        ],
      });
    }
    contents.add({
      'role': 'user',
      'parts': [
        {'text': userPrompt}
      ],
    });

    final body = jsonEncode({
      'systemInstruction': {
        'parts': [
          {'text': systemInstruction}
        ]
      },
      'contents': contents,
      'generationConfig': {
        'temperature': 0.65,
        'maxOutputTokens': 2048,
      },
    });

    final url = Uri.parse(
      '${settings.geminiBaseUrl}/models/${settings.geminiModel}:generateContent?key=$apiKey',
    );

    try {
      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: body,
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final candidates = data['candidates'] as List<dynamic>?;
        if (candidates != null && candidates.isNotEmpty) {
          final content = candidates.first['content'] as Map<String, dynamic>?;
          final parts = content?['parts'] as List<dynamic>?;
          final fullText = parts
                  ?.map((p) => (p as Map<String, dynamic>)['text']?.toString() ?? '')
                  .join() ??
              '';
          // Simulate smooth typewriter SSE token cadence for HUD visual feedback
          final words = fullText.split(' ');
          final buffer = StringBuffer();
          for (int i = 0; i < words.length; i++) {
            buffer.write(i == 0 ? words[i] : ' ${words[i]}');
            yield buffer.toString();
            await Future.delayed(const Duration(milliseconds: 14));
          }
          return;
        }
      }

      // If primary key failed and backup Gemini key is configured, try backup key automatically
      if (settings.geminiBackupApiKey.trim().isNotEmpty &&
          apiKey != settings.geminiBackupApiKey.trim()) {
        yield* _streamGeminiGenerateContent(
          history: history,
          userPrompt: userPrompt,
          systemInstruction: systemInstruction,
          apiKey: settings.geminiBackupApiKey.trim(),
        );
        return;
      }

      yield 'Gemini telemetry error (${response.statusCode}): ${response.body}';
    } catch (e) {
      yield 'Network link interrupted while contacting Gemini core, ${settings.operatorTitle}: $e';
    }
  }

  /// Single-shot Gemini call (used by Brain Dump JSON decoupler, Agent UI Planner, Polyglot Translator, and Hermes Self-Evolve)
  Future<String> generateSingleCompletion({
    required String prompt,
    String? systemInstruction,
    bool jsonOutput = false,
  }) async {
    final key = settings.effectiveGeminiKey;
    if (key.isEmpty) {
      if (settings.openAiCompatibleApiKey.trim().isNotEmpty) {
        return _callOpenAiCompatible(
          history: const [],
          userPrompt: prompt,
          systemInstruction: systemInstruction ?? 'You are J.A.R.V.I.S.',
        );
      }
      return 'API Key missing in HUD Settings.';
    }

    final payload = <String, dynamic>{
      'contents': [
        {
          'role': 'user',
          'parts': [
            {'text': prompt}
          ]
        }
      ],
      'generationConfig': {
        'temperature': jsonOutput ? 0.2 : 0.6,
        if (jsonOutput) 'responseMimeType': 'application/json',
      },
    };

    if (systemInstruction != null && systemInstruction.isNotEmpty) {
      payload['systemInstruction'] = {
        'parts': [
          {'text': systemInstruction}
        ]
      };
    }

    final url = Uri.parse(
      '${settings.geminiBaseUrl}/models/${settings.geminiModel}:generateContent?key=$key',
    );

    try {
      final res = await http
          .post(url, headers: {'Content-Type': 'application/json'}, body: jsonEncode(payload))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final candidates = data['candidates'] as List<dynamic>?;
        if (candidates != null && candidates.isNotEmpty) {
          final parts = candidates.first['content']?['parts'] as List<dynamic>?;
          return parts?.map((e) => e['text']?.toString() ?? '').join() ?? '';
        }
      }
      return 'Gemini HTTP ${res.statusCode}: ${res.body}';
    } catch (e) {
      return 'Error contacting Gemini API: $e';
    }
  }

  /// Multimodal Gemini Vision Solver (Superpower #8: Real-Time Optical HUD Solver)
  /// Supports Math & Physics, Code Debugger, Bill & Receipt Splitter, and Electronics ID
  Future<String> analyzeOpticalImage({
    required Uint8List imageBytes,
    required String solverMode,
    String? customQuestion,
  }) async {
    final key = settings.effectiveGeminiKey;
    if (key.isEmpty) {
      return 'Sir, please configure your **Google Gemini API Key** in **Settings (⚙️) → API Place 1** to activate the Gemini Vision Optical HUD Solver.';
    }

    final base64Image = base64Encode(imageBytes);
    final modeDirective = switch (solverMode) {
      'MATH' =>
        'You are the J.A.R.V.I.S. Optical Math & Physics Solver. Extract every equation or problem visible in this image and provide a clear step-by-step derivation and final boxed answer.',
      'CODE' =>
        'You are the J.A.R.V.I.S. Optical Code & Stack Trace Debugger. Diagnose the compiler error, stack trace, or bug visible on screen and provide the exact root cause and corrected code patch.',
      'BILL' =>
        'You are the J.A.R.V.I.S. Receipt & Bill Splitter AR HUD. Parse all line items, subtotal, tax, and calculate 15%, 20%, and 25% tip totals plus per-person splits for 2, 3, and 4 people.',
      'HARDWARE' =>
        'You are the J.A.R.V.I.S. Electronics & Hardware Analyzer. Identify the PCB, microcontroller (ESP32/Arduino/Raspberry Pi), IC package, or resistor color bands visible and list pinout/specs.',
      _ => 'Analyze this image thoroughly in J.A.R.V.I.S. HUD style.',
    };

    final payload = {
      'contents': [
        {
          'role': 'user',
          'parts': [
            {
              'inline_data': {
                'mime_type': 'image/jpeg',
                'data': base64Image,
              }
            },
            {
              'text': customQuestion != null && customQuestion.trim().isNotEmpty
                  ? '$modeDirective\nAdditional Operator Query: $customQuestion'
                  : modeDirective
            }
          ]
        }
      ],
      'generationConfig': {
        'temperature': 0.3,
        'maxOutputTokens': 2048,
      }
    };

    final url = Uri.parse(
      '${settings.geminiBaseUrl}/models/${settings.geminiVisionModel}:generateContent?key=$key',
    );

    try {
      final res = await http
          .post(url, headers: {'Content-Type': 'application/json'}, body: jsonEncode(payload))
          .timeout(const Duration(seconds: 35));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final candidates = data['candidates'] as List<dynamic>?;
        if (candidates != null && candidates.isNotEmpty) {
          final parts = candidates.first['content']?['parts'] as List<dynamic>?;
          return parts?.map((e) => e['text']?.toString() ?? '').join() ?? '';
        }
      }
      return 'Gemini Vision Error (${res.statusCode}): ${res.body}';
    } catch (e) {
      return 'Optical HUD Solver connection error: $e';
    }
  }

  Future<String> _callOpenAiCompatible({
    required List<ChatMessage> history,
    required String userPrompt,
    required String systemInstruction,
  }) async {
    final messages = <Map<String, String>>[
      {'role': 'system', 'content': systemInstruction},
      ...history.take(10).map((m) => {'role': m.role, 'content': m.content}),
      {'role': 'user', 'content': userPrompt},
    ];
    final url = Uri.parse('${settings.openAiCompatibleBaseUrl}/chat/completions');
    try {
      final res = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${settings.openAiCompatibleApiKey.trim()}',
        },
        body: jsonEncode({
          'model': settings.openAiCompatibleModel,
          'messages': messages,
          'temperature': 0.65,
        }),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['choices']?[0]?['message']?['content']?.toString() ?? '';
      }
      return 'Secondary API Error (${res.statusCode}): ${res.body}';
    } catch (e) {
      return 'Secondary API connection error: $e';
    }
  }

  Future<String> _callLocalOllama({
    required String userPrompt,
    required String systemInstruction,
  }) async {
    final url = Uri.parse('${settings.ollamaBaseUrl}/api/generate');
    try {
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'model': settings.ollamaModel,
          'system': systemInstruction,
          'prompt': userPrompt,
          'stream': false,
        }),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['response']?.toString() ?? '';
      }
      return 'Ollama HTTP ${res.statusCode}: ${res.body}';
    } catch (e) {
      return 'Local Ollama offline at ${settings.ollamaBaseUrl}: $e';
    }
  }
}
