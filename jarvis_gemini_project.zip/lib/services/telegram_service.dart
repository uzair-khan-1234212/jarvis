import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/api_settings_model.dart';

/// Telegram Bot Remote Terminal & Sentry Mode Intruder Alert Dispatcher
class TelegramService {
  ApiSettingsModel settings;
  Timer? _pollingTimer;
  int _lastUpdateId = 0;

  final Future<String> Function(String remoteCommand) onRemoteCommandReceived;

  TelegramService({
    required this.settings,
    required this.onRemoteCommandReceived,
  });

  void updateSettings(ApiSettingsModel newSettings) {
    settings = newSettings;
    if (settings.telegramRemotePollingEnabled &&
        settings.telegramBotToken.trim().isNotEmpty) {
      startPolling();
    } else {
      stopPolling();
    }
  }

  void startPolling() {
    _pollingTimer?.cancel();
    if (settings.telegramBotToken.trim().isEmpty) return;
    _pollingTimer = Timer.periodic(const Duration(seconds: 6), (_) => _pollUpdates());
  }

  void stopPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = null;
  }

  Future<void> _pollUpdates() async {
    final token = settings.telegramBotToken.trim();
    if (token.isEmpty) return;
    try {
      final url = Uri.parse(
        'https://api.telegram.org/bot$token/getUpdates?offset=${_lastUpdateId + 1}&timeout=2',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final results = data['result'] as List<dynamic>? ?? [];
        for (final item in results) {
          final update = item as Map<String, dynamic>;
          _lastUpdateId = (update['update_id'] as int?) ?? _lastUpdateId;
          final message = update['message'] as Map<String, dynamic>?;
          if (message == null) continue;
          final chatId = message['chat']?['id']?.toString() ?? '';
          final text = message['text']?.toString().trim() ?? '';
          if (text.isEmpty) continue;

          // If operator restricted to a specific Chat ID, verify it
          if (settings.telegramChatId.trim().isNotEmpty &&
              chatId != settings.telegramChatId.trim()) {
            continue;
          }

          final reply = await onRemoteCommandReceived(text);
          await sendMessage(reply, overrideChatId: chatId);
        }
      }
    } catch (_) {}
  }

  Future<bool> sendMessage(String text, {String? overrideChatId}) async {
    final token = settings.telegramBotToken.trim();
    final chatId = overrideChatId ?? settings.telegramChatId.trim();
    if (token.isEmpty || chatId.isEmpty) return false;

    try {
      final url = Uri.parse('https://api.telegram.org/bot$token/sendMessage');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'chat_id': chatId,
          'text': text,
        }),
      );
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
