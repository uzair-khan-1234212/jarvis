import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/api_settings_model.dart';
import 'screens/home_hud_screen.dart';
import 'services/hermes_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );

  final settings = await ApiSettingsModel.load();
  final hermesService = HermesService();
  await hermesService.initialize();

  runApp(JarvisGeminiApp(
    settings: settings,
    hermesService: hermesService,
  ));
}

class JarvisGeminiApp extends StatelessWidget {
  final ApiSettingsModel settings;
  final HermesService hermesService;

  const JarvisGeminiApp({
    super.key,
    required this.settings,
    required this.hermesService,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'J.A.R.V.I.S.',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF050A14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E5FF),
          secondary: Color(0xFF00E676),
          surface: Color(0xFF0B1528),
        ),
      ),
      home: HomeHudScreen(
        settings: settings,
        hermesService: hermesService,
      ),
    );
  }
}
