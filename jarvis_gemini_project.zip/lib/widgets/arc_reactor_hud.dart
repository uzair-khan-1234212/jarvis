import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/jarvis_state.dart';

/// Dual Holographic Visual HUD Engine:
/// 1. Arc Reactor Core (Default): 3D spherical consciousness core, gyroscopic armillary rings,
///    triple-ring orbital rotation, and 360° radial audio spectrum.
/// 2. Jarvis Hologram Suit Bust: Translucent cybernetic avatar, elliptical emitter pedestal,
///    horizontal raster scanlines, and audio-reactive chest reactor pulse.
class DualHologramHudWidget extends StatefulWidget {
  final JarvisAuraState auraState;
  final HudProjectionStyle projectionStyle;
  final double soundLevel; // 0.0 .. 1.0
  final VoidCallback onCoreTapped;

  const DualHologramHudWidget({
    super.key,
    required this.auraState,
    required this.projectionStyle,
    required this.soundLevel,
    required this.onCoreTapped,
  });

  @override
  State<DualHologramHudWidget> createState() => _DualHologramHudWidgetState();
}

class _DualHologramHudWidgetState extends State<DualHologramHudWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auraColor = widget.auraState.color;
    return GestureDetector(
      onTap: widget.onCoreTapped,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 280,
                height: 280,
                child: CustomPaint(
                  painter: widget.projectionStyle == HudProjectionStyle.arcReactorCore
                      ? _ArcReactorCorePainter(
                          phase: _controller.value * 2 * math.pi,
                          color: auraColor,
                          soundLevel: widget.soundLevel,
                        )
                      : _HologramSuitBustPainter(
                          phase: _controller.value * 2 * math.pi,
                          color: auraColor,
                          soundLevel: widget.soundLevel,
                        ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: auraColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: auraColor.withOpacity(0.55), width: 1.2),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: auraColor,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: auraColor, blurRadius: 8, spreadRadius: 1),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${widget.auraState.label} (${widget.auraState.hexCode})',
                      style: TextStyle(
                        color: auraColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ArcReactorCorePainter extends CustomPainter {
  final double phase;
  final Color color;
  final double soundLevel;

  _ArcReactorCorePainter({
    required this.phase,
    required this.color,
    required this.soundLevel,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;

    // Ambient outer glow
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          color.withOpacity(0.32 + soundLevel * 0.25),
          color.withOpacity(0.08),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: maxRadius));
    canvas.drawCircle(center, maxRadius, glowPaint);

    // Outer segmented stator ring (counter-rotating)
    final ringPaint = Paint()
      ..color = color.withOpacity(0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-phase * 0.6);
    for (int i = 0; i < 12; i++) {
      final startAngle = (i * math.pi / 6) + 0.06;
      canvas.drawArc(
        Rect.fromCircle(center: Offset.zero, radius: maxRadius * 0.86),
        startAngle,
        math.pi / 9,
        false,
        ringPaint,
      );
    }
    canvas.restore();

    // Gyroscopic armillary middle rings
    final gyroPaint = Paint()
      ..color = color.withOpacity(0.65)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(phase * 1.2);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: maxRadius * 1.38,
        height: maxRadius * (0.95 + 0.25 * math.sin(phase)),
      ),
      gyroPaint,
    );
    canvas.rotate(math.pi / 3);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: maxRadius * 1.25,
        height: maxRadius * (0.85 + 0.25 * math.cos(phase)),
      ),
      gyroPaint,
    );
    canvas.restore();

    // 360° Radial Audio Spectrum Bars
    final barPaint = Paint()
      ..color = color
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;

    const int barCount = 48;
    final baseSpectrumRadius = maxRadius * 0.48;
    for (int i = 0; i < barCount; i++) {
      final angle = (i * 2 * math.pi / barCount) + phase * 0.3;
      final wave = (math.sin(angle * 4 + phase * 3).abs() * 10.0) +
          (soundLevel * 28.0 * (0.5 + 0.5 * math.cos(i * 1.7 + phase * 5)));
      final p1 = Offset(
        center.dx + baseSpectrumRadius * math.cos(angle),
        center.dy + baseSpectrumRadius * math.sin(angle),
      );
      final p2 = Offset(
        center.dx + (baseSpectrumRadius + 6 + wave) * math.cos(angle),
        center.dy + (baseSpectrumRadius + 6 + wave) * math.sin(angle),
      );
      canvas.drawLine(p1, p2, barPaint);
    }

    // Inner Consciousness Core
    final coreRadius = maxRadius * (0.28 + soundLevel * 0.08);
    final corePaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.white,
          color,
          color.withOpacity(0.2),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: coreRadius));
    canvas.drawCircle(center, coreRadius, corePaint);

    // Core geometric triangle/hex overlay
    final hexPaint = Paint()
      ..color = Colors.white.withOpacity(0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final a = (i * math.pi / 3) + phase;
      final pt = Offset(
        center.dx + coreRadius * 0.72 * math.cos(a),
        center.dy + coreRadius * 0.72 * math.sin(a),
      );
      if (i == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    path.close();
    canvas.drawPath(path, hexPaint);
  }

  @override
  bool shouldRepaint(covariant _ArcReactorCorePainter oldDelegate) => true;
}

class _HologramSuitBustPainter extends CustomPainter {
  final double phase;
  final Color color;
  final double soundLevel;

  _HologramSuitBustPainter({
    required this.phase,
    required this.color,
    required this.soundLevel,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    final wirePaint = Paint()
      ..color = color.withOpacity(0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final fillPaint = Paint()
      ..color = color.withOpacity(0.12)
      ..style = PaintingStyle.fill;

    // 1. Elliptical Emitter Pedestal at Bottom
    final pedestalRect = Rect.fromCenter(
      center: Offset(cx, size.height * 0.88),
      width: size.width * 0.74,
      height: 26,
    );
    canvas.drawOval(pedestalRect, fillPaint);
    canvas.drawOval(pedestalRect, wirePaint);

    // Hologram projection cone beams
    final beamPaint = Paint()
      ..color = color.withOpacity(0.18)
      ..strokeWidth = 1.2;
    canvas.drawLine(Offset(cx - size.width * 0.35, size.height * 0.88), Offset(cx - 75, 45), beamPaint);
    canvas.drawLine(Offset(cx + size.width * 0.35, size.height * 0.88), Offset(cx + 75, 45), beamPaint);

    // 2. Cybernetic Iron Man Helmet Silhouette
    final helmet = Path()
      ..moveTo(cx, 32)
      ..lineTo(cx + 38, 46)
      ..lineTo(cx + 44, 86)
      ..lineTo(cx + 32, 126)
      ..lineTo(cx + 16, 140)
      ..lineTo(cx - 16, 140)
      ..lineTo(cx - 32, 126)
      ..lineTo(cx - 44, 86)
      ..lineTo(cx - 38, 46)
      ..close();
    canvas.drawPath(helmet, fillPaint);
    canvas.drawPath(helmet, wirePaint);

    // Glowing Cybernetic Eyes
    final eyePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    canvas.drawRect(Rect.fromLTWH(cx - 28, 78, 18, 6), eyePaint);
    canvas.drawRect(Rect.fromLTWH(cx + 10, 78, 18, 6), eyePaint);

    // 3. Shoulders & Armor Torso Bust
    final torso = Path()
      ..moveTo(cx - 32, 144)
      ..lineTo(cx - 95, 168)
      ..lineTo(cx - 82, 232)
      ..lineTo(cx + 82, 232)
      ..lineTo(cx + 95, 168)
      ..lineTo(cx + 32, 144)
      ..close();
    canvas.drawPath(torso, fillPaint);
    canvas.drawPath(torso, wirePaint);

    // 4. Audio-Reactive Chest Arc Reactor Pulse
    final chestCenter = Offset(cx, 188);
    final pulseRadius = 18.0 + (soundLevel * 12.0) + (2.5 * math.sin(phase * 4));
    final chestPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.white, color, Colors.transparent],
      ).createShader(Rect.fromCircle(center: chestCenter, radius: pulseRadius * 1.4));
    canvas.drawCircle(chestCenter, pulseRadius * 1.4, chestPaint);
    canvas.drawCircle(chestCenter, 14, wirePaint);

    // 5. Horizontal Raster Scanlines
    final scanPaint = Paint()
      ..color = color.withOpacity(0.26)
      ..strokeWidth = 1.0;
    final scanOffset = (phase * 25) % 8;
    for (double y = 35 + scanOffset; y < 235; y += 8) {
      canvas.drawLine(Offset(cx - 90, y), Offset(cx + 90, y), scanPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _HologramSuitBustPainter oldDelegate) => true;
}
