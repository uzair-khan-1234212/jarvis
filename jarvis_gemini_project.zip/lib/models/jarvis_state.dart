import 'package:flutter/material.dart';

/// 5 Operational Reactive Aura States matching the J.A.R.V.I.S. specification
enum JarvisAuraState {
  standbyIdle,       // #00E5FF Electric Arc Cyan
  activeListening,   // #00E676 Emerald Neon Green
  computingThinking, // #BA68C8 Quantum Violet Purple
  speakingVocalizing,// #FFB300 Radiant Solar Gold
  tacticalLockdown,  // #FF1744 Emergency Crimson Red
}

extension JarvisAuraStateExt on JarvisAuraState {
  Color get color {
    switch (this) {
      case JarvisAuraState.standbyIdle:
        return const Color(0xFF00E5FF);
      case JarvisAuraState.activeListening:
        return const Color(0xFF00E676);
      case JarvisAuraState.computingThinking:
        return const Color(0xFFBA68C8);
      case JarvisAuraState.speakingVocalizing:
        return const Color(0xFFFFB300);
      case JarvisAuraState.tacticalLockdown:
        return const Color(0xFFFF1744);
    }
  }

  String get hexCode {
    switch (this) {
      case JarvisAuraState.standbyIdle:
        return '#00E5FF';
      case JarvisAuraState.activeListening:
        return '#00E676';
      case JarvisAuraState.computingThinking:
        return '#BA68C8';
      case JarvisAuraState.speakingVocalizing:
        return '#FFB300';
      case JarvisAuraState.tacticalLockdown:
        return '#FF1744';
    }
  }

  String get label {
    switch (this) {
      case JarvisAuraState.standbyIdle:
        return 'STANDBY // ELECTRIC ARC CYAN';
      case JarvisAuraState.activeListening:
        return 'RECEPTORS OPEN // EMERALD NEON';
      case JarvisAuraState.computingThinking:
        return 'GEMINI COGNITION // QUANTUM VIOLET';
      case JarvisAuraState.speakingVocalizing:
        return 'VOCAL SYNTHESIS // SOLAR GOLD';
      case JarvisAuraState.tacticalLockdown:
        return 'TACTICAL ALERT // CRIMSON LOCKDOWN';
    }
  }
}

/// The 3 Operational Modes
enum JarvisOperationalMode {
  jarvisVoiceHud, // Hands-Free Voice & 3D Cyber HUD
  autonomousAgent,// Observe -> Think -> Act UI Automation
  streamingChat,  // High-Speed Conversational Streaming
}

/// Dual Holographic Visual Projections
enum HudProjectionStyle {
  arcReactorCore,   // 3D spherical consciousness core + gyroscopic rings
  hologramSuitBust, // Translucent cybernetic Iron Man bust + raster scanlines
}

class ChatMessage {
  final String id;
  final String role; // 'user', 'assistant', 'system'
  String content;
  final DateTime timestamp;
  final String? providerBadge;

  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    DateTime? timestamp,
    this.providerBadge,
  }) : timestamp = timestamp ?? DateTime.now();
}
