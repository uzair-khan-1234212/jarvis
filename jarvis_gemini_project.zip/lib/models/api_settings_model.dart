import 'package:shared_preferences/shared_preferences.dart';

/// Multi-Place API Configuration Model
/// Allows the operator to configure separate API keys and endpoints in Settings
/// AFTER installing the APK (Google Gemini Primary, Gemini Backup/Vision,
/// OpenRouter/OpenAI/DeepSeek, Local Ollama, Telegram Bot, and Voice/TTS API).
class ApiSettingsModel {
  // Active Backend Selector: 'gemini', 'openai_compatible', 'ollama'
  String activeProvider;

  // --- API PLACE 1: Google Gemini Primary & Vision Engine ---
  String geminiPrimaryApiKey;
  String geminiBackupApiKey;
  String geminiModel;       // e.g. 'gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'
  String geminiVisionModel; // e.g. 'gemini-2.5-flash'
  String geminiBaseUrl;     // Default: https://generativelanguage.googleapis.com/v1beta

  // --- API PLACE 2: OpenRouter / OpenAI / DeepSeek / NVIDIA NIM ---
  String openAiCompatibleApiKey;
  String openAiCompatibleBaseUrl; // e.g. https://openrouter.ai/api/v1 or https://api.deepseek.com/v1
  String openAiCompatibleModel;   // e.g. deepseek-chat or gpt-4o-mini

  // --- API PLACE 3: Local Offline Ollama Instance ---
  String ollamaBaseUrl; // e.g. http://127.0.0.1:11434
  String ollamaModel;   // e.g. llama3.2:latest

  // --- API PLACE 4: Telegram Remote Terminal & Sentry Alert API ---
  String telegramBotToken;
  String telegramChatId;
  bool telegramRemotePollingEnabled;

  // --- API PLACE 5: Voice / Neural TTS & Wake-Word Settings ---
  String customVoiceTtsApiKey; // Optional ElevenLabs / Cloud TTS key
  String voiceLocale;          // Default: en-GB
  double speechRate;
  double speechPitch;
  bool alwaysOnWakeWord;
  String operatorTitle;        // Default: "Sir"

  ApiSettingsModel({
    this.activeProvider = 'gemini',
    this.geminiPrimaryApiKey = '',
    this.geminiBackupApiKey = '',
    this.geminiModel = 'gemini-2.5-flash',
    this.geminiVisionModel = 'gemini-2.5-flash',
    this.geminiBaseUrl = 'https://generativelanguage.googleapis.com/v1beta',
    this.openAiCompatibleApiKey = '',
    this.openAiCompatibleBaseUrl = 'https://openrouter.ai/api/v1',
    this.openAiCompatibleModel = 'deepseek/deepseek-chat',
    this.ollamaBaseUrl = 'http://127.0.0.1:11434',
    this.ollamaModel = 'llama3.2',
    this.telegramBotToken = '',
    this.telegramChatId = '',
    this.telegramRemotePollingEnabled = false,
    this.customVoiceTtsApiKey = '',
    this.voiceLocale = 'en-GB',
    this.speechRate = 0.52,
    this.speechPitch = 0.95,
    this.alwaysOnWakeWord = false,
    this.operatorTitle = 'Sir',
  });

  bool get hasGeminiKey =>
      geminiPrimaryApiKey.trim().isNotEmpty || geminiBackupApiKey.trim().isNotEmpty;

  String get effectiveGeminiKey =>
      geminiPrimaryApiKey.trim().isNotEmpty
          ? geminiPrimaryApiKey.trim()
          : geminiBackupApiKey.trim();

  static Future<ApiSettingsModel> load() async {
    final prefs = await SharedPreferences.getInstance();
    return ApiSettingsModel(
      activeProvider: prefs.getString('activeProvider') ?? 'gemini',
      geminiPrimaryApiKey: prefs.getString('geminiPrimaryApiKey') ?? '',
      geminiBackupApiKey: prefs.getString('geminiBackupApiKey') ?? '',
      geminiModel: prefs.getString('geminiModel') ?? 'gemini-2.5-flash',
      geminiVisionModel: prefs.getString('geminiVisionModel') ?? 'gemini-2.5-flash',
      geminiBaseUrl: prefs.getString('geminiBaseUrl') ?? 'https://generativelanguage.googleapis.com/v1beta',
      openAiCompatibleApiKey: prefs.getString('openAiCompatibleApiKey') ?? '',
      openAiCompatibleBaseUrl: prefs.getString('openAiCompatibleBaseUrl') ?? 'https://openrouter.ai/api/v1',
      openAiCompatibleModel: prefs.getString('openAiCompatibleModel') ?? 'deepseek/deepseek-chat',
      ollamaBaseUrl: prefs.getString('ollamaBaseUrl') ?? 'http://127.0.0.1:11434',
      ollamaModel: prefs.getString('ollamaModel') ?? 'llama3.2',
      telegramBotToken: prefs.getString('telegramBotToken') ?? '',
      telegramChatId: prefs.getString('telegramChatId') ?? '',
      telegramRemotePollingEnabled: prefs.getBool('telegramRemotePollingEnabled') ?? false,
      customVoiceTtsApiKey: prefs.getString('customVoiceTtsApiKey') ?? '',
      voiceLocale: prefs.getString('voiceLocale') ?? 'en-GB',
      speechRate: prefs.getDouble('speechRate') ?? 0.52,
      speechPitch: prefs.getDouble('speechPitch') ?? 0.95,
      alwaysOnWakeWord: prefs.getBool('alwaysOnWakeWord') ?? false,
      operatorTitle: prefs.getString('operatorTitle') ?? 'Sir',
    );
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('activeProvider', activeProvider);
    await prefs.setString('geminiPrimaryApiKey', geminiPrimaryApiKey.trim());
    await prefs.setString('geminiBackupApiKey', geminiBackupApiKey.trim());
    await prefs.setString('geminiModel', geminiModel.trim());
    await prefs.setString('geminiVisionModel', geminiVisionModel.trim());
    await prefs.setString('geminiBaseUrl', geminiBaseUrl.trim());
    await prefs.setString('openAiCompatibleApiKey', openAiCompatibleApiKey.trim());
    await prefs.setString('openAiCompatibleBaseUrl', openAiCompatibleBaseUrl.trim());
    await prefs.setString('openAiCompatibleModel', openAiCompatibleModel.trim());
    await prefs.setString('ollamaBaseUrl', ollamaBaseUrl.trim());
    await prefs.setString('ollamaModel', ollamaModel.trim());
    await prefs.setString('telegramBotToken', telegramBotToken.trim());
    await prefs.setString('telegramChatId', telegramChatId.trim());
    await prefs.setBool('telegramRemotePollingEnabled', telegramRemotePollingEnabled);
    await prefs.setString('customVoiceTtsApiKey', customVoiceTtsApiKey.trim());
    await prefs.setString('voiceLocale', voiceLocale.trim());
    await prefs.setDouble('speechRate', speechRate);
    await prefs.setDouble('speechPitch', speechPitch);
    await prefs.setBool('alwaysOnWakeWord', alwaysOnWakeWord);
    await prefs.setString('operatorTitle', operatorTitle.trim());
  }
}
