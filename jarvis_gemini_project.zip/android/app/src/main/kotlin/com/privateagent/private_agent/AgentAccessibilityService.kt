package com.privateagent.private_agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AgentAccessibilityService? = null
        var isRecordingMacro: Boolean = false
        val recordedMacroSteps = mutableListOf<Map<String, Any>>()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (isRecordingMacro && (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
                    event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED)) {
            val pkg = event.packageName?.toString() ?: "unknown"
            val text = event.text.joinToString(" ")
            val contentDesc = event.contentDescription?.toString() ?: ""
            val rect = Rect()
            event.source?.getBoundsInScreen(rect)
            recordedMacroSteps.add(
                mapOf(
                    "eventType" to AccessibilityEvent.eventTypeToString(event.eventType),
                    "package" to pkg,
                    "text" to text,
                    "contentDescription" to contentDesc,
                    "centerX" to rect.centerX(),
                    "centerY" to rect.centerY(),
                    "timestamp" to System.currentTimeMillis()
                )
            )
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    fun dumpScreenHierarchy(): String {
        val root = rootInActiveWindow ?: return "[No Active Window Hierarchy Available]"
        val sb = StringBuilder()
        sb.append("PACKAGE: ").append(root.packageName ?: "unknown").append("\n")
        traverseNode(root, 0, sb)
        return sb.toString()
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, depth: Int, sb: StringBuilder) {
        if (node == null || depth > 14) return
        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""
        val viewId = node.viewIdResourceName?.substringAfter("/") ?: ""
        val clickable = node.isClickable
        val editable = node.isEditable

        if (text.isNotEmpty() || desc.isNotEmpty() || clickable || editable) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val indent = "  ".repeat(depth.coerceAtMost(6))
            sb.append(indent)
                .append("[")
                .append(node.className?.toString()?.substringAfterLast('.') ?: "View")
                .append("]")
            if (viewId.isNotEmpty()) sb.append(" id=").append(viewId)
            if (text.isNotEmpty()) sb.append(" text=\"").append(text.take(80)).append("\"")
            if (desc.isNotEmpty()) sb.append(" desc=\"").append(desc.take(60)).append("\"")
            if (clickable) sb.append(" [CLICKABLE]")
            if (editable) sb.append(" [EDITABLE]")
            sb.append(" @(").append(rect.centerX()).append(",").append(rect.centerY()).append(")\n")
        }

        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), depth + 1, sb)
        }
    }

    fun performTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 90)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun performSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(100L, 2000L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun inputTextIntoFocusedNode(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findFirstEditable(root)
        if (focused != null) {
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        return false
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    fun triggerGlobalAction(action: String): Boolean {
        return when (action.uppercase()) {
            "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "RECENTS" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "NOTIFICATIONS" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            else -> performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }
}
