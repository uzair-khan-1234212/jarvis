package com.privateagent.private_agent

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class InboxNotificationListenerService : NotificationListenerService() {
    companion object {
        val recentNotifications = mutableListOf<Map<String, String>>()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isNotEmpty() || text.isNotEmpty()) {
            synchronized(recentNotifications) {
                recentNotifications.add(
                    0,
                    mapOf(
                        "package" to pkg,
                        "title" to title,
                        "text" to text,
                        "timestamp" to sbn.postTime.toString()
                    )
                )
                if (recentNotifications.size > 25) {
                    recentNotifications.removeAt(recentNotifications.lastIndex)
                }
            }
        }
    }
}
