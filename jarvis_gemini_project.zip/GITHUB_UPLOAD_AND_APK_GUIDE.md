# 📦 Step-by-Step Guide: Uploading J.A.R.V.I.S. to GitHub & Installing Your APK

You don't need Android Studio or Flutter installed on your computer—GitHub's cloud servers will automatically build the `.apk` for you using the included `.github/workflows/build-apk.yml` workflow.

---

## Method A: Upload Using the GitHub Website (No Coding Tools Needed)

1. **Extract the ZIP**:
   - Unzip `Jarvis-Gemini-Android.zip` into a folder on your device.
   - Make sure hidden folders like `.github` are visible when extracting.
2. **Create a GitHub Repository**:
   - Go to [https://github.com/new](https://github.com/new).
   - Repository name: `Jarvis` (or `My-Jarvis`).
   - Choose **Public** (or Private) and click **Create repository**.
3. **Upload the Files**:
   - On your new repository page, click **uploading an existing file** (or **Add file → Upload files**).
   - Drag and drop **all** folders and files from inside the unzipped folder (`.github`, `android`, `assets`, `lib`, `pubspec.yaml`, `analysis_options.yaml`, `README.md`, `LICENSE`) into the browser window.
   - Click the green **Commit changes** button at the bottom.

---

## Method B: Upload Using Git Command Line (Fastest)

If you have Git installed, open a terminal inside the unzipped folder and run:

```bash
git init
git add .
git commit -m "feat: launch J.A.R.V.I.S. Gemini Edition v1.1.0"
git branch -M main
git remote add origin https://github.com/<YOUR-GITHUB-USERNAME>/<YOUR-REPO-NAME>.git
git push -u origin main
```

---

## 📱 How to Download & Install the Built APK

1. Open your repository on GitHub and click the **Actions** tab at the top.
2. Click on the workflow run titled **"Build J.A.R.V.I.S. Android APK"**.
   - *(Tip: You can also trigger a build manually anytime by clicking **Build J.A.R.V.I.S. Android APK → Run workflow**).*
3. Wait ~3–4 minutes for the green checkmark ✅.
4. Download your APK from either place:
   - **Releases Page (Direct APK download on phone)**: Go to your repo's main page → tap **Releases** (`J.A.R.V.I.S. (Gemini Edition) v1.1.0`) → tap **`Jarvis-Gemini-v1.1.0-release.apk`**.
   - **Actions Artifacts**: Inside the finished Actions run, scroll to the bottom **Artifacts** section and download **`Jarvis-Gemini-Android-APK`**.
5. Tap the downloaded `.apk` on your Android phone to install.

---

## 🔑 Adding Your API Keys Inside the App (After Install)

1. Launch **J.A.R.V.I.S.** on your phone.
2. Tap the **Settings (`⚙️`)** icon in the top-right corner of the HUD.
3. Under the **5 API SLOTS & KEYS** tab, fill in the slots you want to use:
   - **API Place 1 (Google Gemini Code & Vision)**: Paste your Primary Google Gemini API Key (from [Google AI Studio](https://aistudio.google.com/apikey)) and optional Backup Gemini Key, then tap **SAVE & TEST GEMINI API KEY**.
   - **API Place 2 (OpenRouter / OpenAI / DeepSeek)**: Optional key and base URL for secondary models.
   - **API Place 3 (Local Offline Ollama)**: Optional `http://127.0.0.1:11434` endpoint.
   - **API Place 4 (Telegram Remote & Sentry Bot)**: Optional Telegram Bot Token and Chat ID for remote commands and Sentry motion alerts.
   - **API Place 5 (Voice TTS & Operator Identity)**: Set how J.A.R.V.I.S. addresses you (`Sir`, `Boss`, etc.), voice locale (`en-GB`), and optional custom Voice TTS API key.
4. Tap **SAVE** in the top-right corner of Settings.
