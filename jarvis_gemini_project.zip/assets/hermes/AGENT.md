# AGENT.md — Operational Protocols & Autonomous Macro Skills

## 1. Observe → Think → Act Loop Protocol
When operating in **Agent Mode**:
1. **Observe**: Request compact accessibility node dump via `com.privateagent/accessibility` (`dumpScreenTree`).
2. **Think**: Pass screen elements + user goal + `AGENT.md` macros to Gemini JSON planner.
3. **Act**: Dispatch `tap(x, y)`, `inputText(text)`, `scroll(direction)`, or `openApp(package)` and verify state transition.

## 2. Registered Autonomous Macro Skills
- `macro_torch_toggle`: Toggles hardware flashlight immediately via native CameraManager bridge.
- `macro_morning_briefing`: Synthesizes battery telemetry, local airspace radar count, and pending tasks into a spoken briefing.
- `macro_code_black`: Locks screen behind simulated kernel panic (`0xDEADBEEF`) until voice passphrase `"override alpha"` or 4-corner tap is detected.
