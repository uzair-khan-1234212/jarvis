# USER.md — Operator Profile & Learned Preferences

## 1. Operator Profile
- **Preferred Title**: Sir
- **Primary AI Engine**: Google Gemini (`gemini-2.5-flash`)
- **Preferred Voice**: Studio British Neural (`en-GB`)
- **Wake Word**: "Hey Jarvis" / "Jarvis" (7.5s continuation window active)

## 2. Learned Habits & Facts
- Prefers concise executive vocal briefings when running multi-task Brain Dump directives.
- Uses multi-slot API Settings to switch between Gemini Flash (speed/vision), Gemini Pro (deep coding/math), and secondary providers.
