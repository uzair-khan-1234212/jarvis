# ⚡ J.A.R.V.I.S. (Gemini Core Edition)

**Autonomous On-Device AI Assistant, Cybernetic HUD & Android UI Automation Framework**  
*Inspired by [AbuZar-Ansarii/Jarvis](https://github.com/AbuZar-Ansarii/Jarvis) — Engineered with First-Class Google Gemini Code & Multi-Slot API Architecture*

---

## 🌟 Overview

**J.A.R.V.I.S. (Gemini Core Edition)** is an autonomous cybernetic Android HUD and OS operator built with Flutter and native Android Kotlin services (`AgentAccessibilityService`, `InboxNotificationListenerService`, and hardware sensor bridges).

### Key Capabilities
1. **Multi-Slot API Hub in Settings (`⚙️`)**: Enter all API keys **after** installing the APK:
   - **API Place 1 — Google Gemini Code & Vision**: Primary Gemini API Key, Backup/Failover Gemini API Key, and model selector (`gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-2.0-flash`).
   - **API Place 2 — OpenRouter / OpenAI / DeepSeek**: Custom base URL, API key, and model tag.
   - **API Place 3 — Local Offline Ollama**: `http://127.0.0.1:11434` for 100% offline local inference.
   - **API Place 4 — Telegram Remote Terminal & Sentry Alert Bot**: Bot Token and Chat ID for `/status`, `/cancel`, remote task execution, and motion-triggered Sentry breach alerts.
   - **API Place 5 — Studio Voice & Operator Profile**: Custom Voice TTS API key, `en-GB` neural voice controls, wake-word receptor (`"Hey Jarvis"`), and live editor for Hermes `SOUL.md`, `USER.md`, and `AGENT.md`.
2. **Dual 3D Holographic Projections & 5 Reactive Aura States**:
   - Switch instantly between the **Arc Reactor Consciousness Core** and the **Jarvis Hologram Suit Bust**.
   - Smoothly shifts aura colors across **Standby Cyan (`#00E5FF`)**, **Active Listening Emerald (`#00E676`)**, **Gemini Thinking Violet (`#BA68C8`)**, **Vocalizing Solar Gold (`#FFB300`)**, and **Tactical Lockdown Crimson (`#FF1744`)**.
3. **The 3 Operational Modes**:
   - **J.A.R.V.I.S. HUD Mode**: Always-on wake word (`"Hey Jarvis"`) with a 7.5-second continuation window.
   - **Agent Mode**: Autonomous `Observe → Think → Act` loop via Android Accessibility node inspection and gesture dispatch.
   - **Chat Mode**: Streaming Markdown/code conversational view.
4. **All 9 Stark Superpowers**:
   - 🖐️ **Iron Man Air Gestures** (Proximity wave controls)
   - ⚡ **Arc Reactor Charging Telemetry** (Watts, mV, °C HUD on power connect)
   - 🌐 **Polyglot Diplomat** (14+ language two-way voice translator)
   - 🎭 **"Code Black" Lockout** (Simulated kernel panic `0xDEADBEEF` with 4-tap corner disarm)
   - 👁️ **Holographic Floating Co-Pilot** (Foreground screen context & reply triage)
   - 📡 **Overhead Airspace & ISS Radar** (OpenSky ADS-B flights + ISS orbital pass)
   - 🧠 **Chaotic Brain Dump Decoupler** (Parallel multi-task execution engine)
   - 👁️ **Real-Time Optical HUD Solver** (Gemini Vision Camera AR for Math, Code, Bills, Hardware)
   - 🛡️ **Stark Network Security Audit** (Gateway & critical port vulnerability sweep)

---

## 🚀 How to Upload to GitHub & Install the APK Automatically

This repository includes an automated GitHub Actions workflow (`.github/workflows/build-apk.yml`) that compiles the Android `.apk` for you in the cloud as soon as you upload the files to GitHub:

1. **Unzip** `Jarvis-Gemini-Android.zip` on your computer or phone.
2. Create a **new repository** on [GitHub](https://github.com/new) (e.g., `Jarvis`).
3. Upload all extracted files and folders (`.github/`, `android/`, `assets/`, `lib/`, `pubspec.yaml`, `README.md`, etc.) to your repository's `main` or `master` branch.
4. Click the **Actions** tab at the top of your GitHub repository:
   - You will see the **"Build J.A.R.V.I.S. Android APK"** workflow running automatically.
   - Once it finishes (around 3–4 minutes), scroll down to **Artifacts** and download **`Jarvis-Gemini-Android-APK`**, OR click the **Releases** section on the right side of your repo page to download **`Jarvis-Gemini-v1.1.0-release.apk`** directly to your Android phone!
5. Install the APK on your Android phone, open **J.A.R.V.I.S.**, tap **Settings (`⚙️`)** in the top-right corner, and paste your **Google Gemini API Key** into **API Place 1**.
