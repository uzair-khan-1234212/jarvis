package com.privateagent.private_agent

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import kotlin.math.sqrt

class MainActivity: FlutterActivity(), SensorEventListener {
    private val ACCESSIBILITY_CHANNEL = "com.privateagent/accessibility"
    private val HARDWARE_CHANNEL = "com.privateagent/hardware"
    private val SENSOR_EVENT_CHANNEL = "com.privateagent/sensor_events"

    private var sensorManager: SensorManager? = null
    private var proximitySensor: Sensor? = null
    private var accelerometer: Sensor? = null
    private var eventSink: EventChannel.EventSink? = null
    private var tts: TextToSpeech? = null
    private var strobeActive = false

    private var airGesturesEnabled = false
    private var sentryModeArmed = false
    private var torchEnabled = false
    private var lastNearTimestamp: Long = 0
    private var waveCount = 0

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.UK }

        // 1. Accessibility & UI Automation Channel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ACCESSIBILITY_CHANNEL).setMethodCallHandler { call, result ->
            val svc = AgentAccessibilityService.instance
            when (call.method) {
                "isAccessibilityEnabled" -> {
                    result.success(svc != null)
                }
                "openAccessibilitySettings" -> {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    result.success(true)
                }
                "dumpScreenTree" -> {
                    if (svc == null) {
                        result.success("[Accessibility Service Offline — Enable in Android Settings > Accessibility > J.A.R.V.I.S.]")
                    } else {
                        result.success(svc.dumpScreenHierarchy())
                    }
                }
                "performTap" -> {
                    val x = (call.argument<Number>("x")?.toFloat()) ?: 500f
                    val y = (call.argument<Number>("y")?.toFloat()) ?: 500f
                    result.success(svc?.performTap(x, y) ?: false)
                }
                "performSwipe" -> {
                    val x1 = (call.argument<Number>("x1")?.toFloat()) ?: 500f
                    val y1 = (call.argument<Number>("y1")?.toFloat()) ?: 1400f
                    val x2 = (call.argument<Number>("x2")?.toFloat()) ?: 500f
                    val y2 = (call.argument<Number>("y2")?.toFloat()) ?: 400f
                    val duration = (call.argument<Number>("duration")?.toLong()) ?: 350L
                    result.success(svc?.performSwipe(x1, y1, x2, y2, duration) ?: false)
                }
                "performInputText" -> {
                    val text = call.argument<String>("text") ?: ""
                    result.success(svc?.inputTextIntoFocusedNode(text) ?: false)
                }
                "performGlobalAction" -> {
                    val action = call.argument<String>("action") ?: "HOME"
                    result.success(svc?.triggerGlobalAction(action) ?: false)
                }
                "startMacroRecording" -> {
                    AgentAccessibilityService.isRecordingMacro = true
                    AgentAccessibilityService.recordedMacroSteps.clear()
                    result.success(true)
                }
                "stopMacroRecording" -> {
                    AgentAccessibilityService.isRecordingMacro = false
                    result.success(AgentAccessibilityService.recordedMacroSteps.toList())
                }
                "getRecentNotifications" -> {
                    result.success(InboxNotificationListenerService.recentNotifications.toList())
                }
                else -> result.notImplemented()
            }
        }

        // 2. Hardware Telemetry, Torch, Volume, Air Gestures & Sentry Channel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, HARDWARE_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "getBatteryTelemetry" -> {
                    result.success(readBatteryTelemetry())
                }
                "toggleFlashlight" -> {
                    val enable = call.argument<Boolean>("enable") ?: !torchEnabled
                    val ok = setTorchState(enable)
                    result.success(ok)
                }
                "adjustVolume" -> {
                    val direction = call.argument<String>("direction") ?: "UP"
                    adjustDeviceVolume(direction)
                    result.success(true)
                }
                "dispatchMediaKey" -> {
                    val key = call.argument<String>("key") ?: "PLAY_PAUSE"
                    sendMediaKeyEvent(key)
                    result.success(true)
                }
                "setAirGestures" -> {
                    airGesturesEnabled = call.argument<Boolean>("enabled") ?: false
                    updateSensorListeners()
                    result.success(airGesturesEnabled)
                }
                "setSentryMode" -> {
                    sentryModeArmed = call.argument<Boolean>("armed") ?: false
                    updateSensorListeners()
                    result.success(sentryModeArmed)
                }
                "speakTts" -> {
                    val text = call.argument<String>("text") ?: ""
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt")
                    result.success(true)
                }
                "stopTts" -> {
                    tts?.stop()
                    result.success(true)
                }
                "setRedAlertStrobe" -> {
                    val active = call.argument<Boolean>("active") ?: false
                    strobeActive = active
                    if (active) {
                        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, 0)
                        Thread {
                            while (strobeActive) {
                                setTorchState(true)
                                triggerAggressiveHaptic()
                                Thread.sleep(160)
                                setTorchState(false)
                                Thread.sleep(140)
                            }
                            setTorchState(false)
                        }.start()
                    } else {
                        setTorchState(false)
                    }
                    result.success(strobeActive)
                }
                "runOverdriveShell" -> {
                    val cmd = call.argument<String>("command") ?: "uname -a"
                    try {
                        val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
                        val reader = BufferedReader(InputStreamReader(proc.inputStream))
                        val out = reader.readText()
                        result.success(if (out.isNotEmpty()) out else "[Command completed with empty stdout]")
                    } catch (e: Exception) {
                        result.success("Shell error: ${e.message}")
                    }
                }
                "triggerHapticAlarm" -> {
                    triggerAggressiveHaptic()
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        // 3. Real-time Sensor & Power Broadcast Stream
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, SENSOR_EVENT_CHANNEL).setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    eventSink = events
                    registerPowerReceiver()
                }
                override fun onCancel(arguments: Any?) {
                    eventSink = null
                }
            }
        )
    }

    private fun updateSensorListeners() {
        sensorManager?.unregisterListener(this)
        if (airGesturesEnabled && proximitySensor != null) {
            sensorManager?.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
        if (sentryModeArmed && accelerometer != null) {
            sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        if (event.sensor.type == Sensor.TYPE_PROXIMITY && airGesturesEnabled) {
            val distance = event.values[0]
            val maxRange = proximitySensor?.maximumRange ?: 5f
            val isNear = distance < maxRange
            val now = System.currentTimeMillis()
            if (isNear) {
                lastNearTimestamp = now
            } else {
                val holdDuration = now - lastNearTimestamp
                if (holdDuration in 900..2500) {
                    sendMediaKeyEvent("PLAY_PAUSE")
                    eventSink?.success(mapOf("type" to "AIR_GESTURE", "gesture" to "PALM_HOVER_PLAY_PAUSE", "distance" to distance))
                } else if (holdDuration in 60..899) {
                    waveCount++
                    sendMediaKeyEvent("NEXT")
                    eventSink?.success(mapOf("type" to "AIR_GESTURE", "gesture" to "QUICK_WAVE_NEXT_TRACK", "distance" to distance))
                }
            }
        } else if (event.sensor.type == Sensor.TYPE_ACCELEROMETER && sentryModeArmed) {
            val ax = event.values[0]
            val ay = event.values[1]
            val az = event.values[2]
            val magnitude = sqrt((ax * ax + ay * ay + az * az).toDouble())
            // Detect motion spike above resting gravity (~9.8 m/s^2)
            if (magnitude > 13.8 || magnitude < 6.2) {
                triggerAggressiveHaptic()
                eventSink?.success(mapOf(
                    "type" to "SENTRY_BREACH",
                    "magnitude" to magnitude,
                    "timestamp" to System.currentTimeMillis()
                ))
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun readBatteryTelemetry(): Map<String, Any> {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 78
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0) (level * 100) / scale else 78
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 4120) ?: 4120
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 314) ?: 314
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val isCharging = plugged != 0

        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val currentNowUa = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val currentMa = kotlin.math.abs(currentNowUa / 1000.0).coerceAtLeast(if (isCharging) 2400.0 else 420.0)
        val watts = ((voltageMv / 1000.0) * (currentMa / 1000.0))

        val medium = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Turbo Flux"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Inductive Flux"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Bus Core"
            else -> "Internal Arc Cells"
        }

        return mapOf(
            "percentage" to pct,
            "voltageMv" to voltageMv,
            "temperatureC" to (tempTenths / 10.0),
            "currentMa" to currentMa,
            "watts" to watts,
            "isCharging" to isCharging,
            "medium" to medium
        )
    }

    private fun setTorchState(enable: Boolean): Boolean {
        return try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return false
            cm.setTorchMode(cameraId, enable)
            torchEnabled = enable
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun adjustDeviceVolume(direction: String) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (direction.uppercase()) {
            "UP" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "DOWN" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "MUTE" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        }
    }

    private fun sendMediaKeyEvent(key: String) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (key.uppercase()) {
            "NEXT" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "PREVIOUS" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun triggerAggressiveHaptic() {
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 180, 80, 240, 80, 320), -1))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(600)
        }
    }

    private fun registerPowerReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val telemetry = readBatteryTelemetry()
                eventSink?.success(mapOf(
                    "type" to "POWER_STATE_CHANGED",
                    "connected" to (intent?.action == Intent.ACTION_POWER_CONNECTED),
                    "telemetry" to telemetry
                ))
            }
        }, filter)
    }
}
