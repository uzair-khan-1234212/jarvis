import 'dart:async';
import 'package:flutter/services.dart';

class VoiceService {
  static const MethodChannel _hw = MethodChannel('com.privateagent/hardware');
  bool isInitialized = true;
  bool isListening = false;
  bool isSpeaking = false;
  bool alwaysOnMode = false;
  double currentSoundLevel = 0.0;

  final void Function(String recognizedText, bool isFinal) onTranscript;
  final void Function(double rmsNormalized) onSoundLevelChanged;
  final void Function(bool speakingState) onSpeakingStateChanged;

  VoiceService({
    required this.onTranscript,
    required this.onSoundLevelChanged,
    required this.onSpeakingStateChanged,
  });

  Future<void> initialize({String locale = 'en-GB', double rate = 0.52, double pitch = 0.95}) async {}
  Future<void> updateVoiceConfig({required String locale, required double rate, required double pitch}) async {}

  Future<void> startListening() async {
    if (isListening) return;
    isListening = true;
    onSoundLevelChanged(0.6);
    try {
      final text = await _hw.invokeMethod<String>('listenSpeechOnce') ?? '';
      isListening = false;
      onSoundLevelChanged(0.0);
      if (text.trim().isNotEmpty) onTranscript(text.trim(), true);
    } catch (_) {
      isListening = false;
      onSoundLevelChanged(0.0);
    }
  }

  Future<void> stopListening() async {
    isListening = false;
    onSoundLevelChanged(0.0);
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    isSpeaking = true;
    onSpeakingStateChanged(true);
    try { await _hw.invokeMethod('speakTts', {'text': text}); } catch (_) {}
    Future.delayed(const Duration(seconds: 3), () {
      isSpeaking = false;
      onSpeakingStateChanged(false);
    });
  }

  Future<void> stopSpeaking() async {
    isSpeaking = false;
    onSpeakingStateChanged(false);
    try { await _hw.invokeMethod('stopTts'); } catch (_) {}
  }

  void dispose() { stopSpeaking(); }
}
