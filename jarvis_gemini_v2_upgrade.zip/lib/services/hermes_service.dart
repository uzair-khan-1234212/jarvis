import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
Future<Directory> getApplicationDocumentsDirectory() async => Directory.systemTemp;
import 'gemini_ai_service.dart';

/// Hermes Tri-Partite Self-Evolution Context Engine
/// Manages SOUL.md (Identity), USER.md (Operator Profile), and AGENT.md (Protocols & Macros)
class HermesService {
  String soulMd = '';
  String userMd = '';
  String agentMd = '';

  Future<void> initialize() async {
    final dir = await getApplicationDocumentsDirectory();
    final soulFile = File('${dir.path}/SOUL.md');
    final userFile = File('${dir.path}/USER.md');
    final agentFile = File('${dir.path}/AGENT.md');

    if (await soulFile.exists()) {
      soulMd = await soulFile.readAsString();
    } else {
      soulMd = await rootBundle.loadString('assets/hermes/SOUL.md');
      await soulFile.writeAsString(soulMd);
    }

    if (await userFile.exists()) {
      userMd = await userFile.readAsString();
    } else {
      userMd = await rootBundle.loadString('assets/hermes/USER.md');
      await userFile.writeAsString(userMd);
    }

    if (await agentFile.exists()) {
      agentMd = await agentFile.readAsString();
    } else {
      agentMd = await rootBundle.loadString('assets/hermes/AGENT.md');
      await agentFile.writeAsString(agentMd);
    }
  }

  Future<void> saveFiles({
    required String newSoul,
    required String newUser,
    required String newAgent,
  }) async {
    final dir = await getApplicationDocumentsDirectory();
    soulMd = newSoul;
    userMd = newUser;
    agentMd = newAgent;
    await File('${dir.path}/SOUL.md').writeAsString(soulMd);
    await File('${dir.path}/USER.md').writeAsString(userMd);
    await File('${dir.path}/AGENT.md').writeAsString(agentMd);
  }

  /// Autonomous Macro Registration into AGENT.md
  Future<void> registerRecordedMacro(String macroName, List<Map<String, dynamic>> steps) async {
    final macroJson = jsonEncode({'name': macroName, 'steps': steps});
    final entry = '\n- `$macroName`: Automated UI Skill (`${steps.length}` actions) -> `$macroJson`';
    agentMd = '$agentMd$entry\n';
    final dir = await getApplicationDocumentsDirectory();
    await File('${dir.path}/AGENT.md').writeAsString(agentMd);
  }

  /// Voice or HUD One-Tap "SELF EVOLVE" Synthesis via Gemini
  Future<String> selfEvolveFromConversation({
    required GeminiAiService aiService,
    required List<String> recentTranscript,
  }) async {
    if (recentTranscript.isEmpty) {
      return 'Hermes Memory matrix is already synchronized, Sir. No new behavioral deltas detected.';
    }

    final prompt = '''
Analyze the following recent operator interactions with J.A.R.V.I.S. and extract any new persistent user facts, preferences, or workflow habits that should be appended to USER.md.
Return ONLY 2-3 concise markdown bullet points to append, plus a 1-sentence spoken executive summary for the operator.

Current USER.md:
$userMd

Recent Transcript:
${recentTranscript.join("\n")}
''';

    final synthesis = await aiService.generateSingleCompletion(prompt: prompt);
    if (!synthesis.startsWith('API Key missing') && !synthesis.startsWith('Error')) {
      final timestamp = DateTime.now().toIso8601String().substring(0, 16);
      userMd = '$userMd\n\n### Hermes Evolution ($timestamp)\n$synthesis';
      final dir = await getApplicationDocumentsDirectory();
      await File('${dir.path}/USER.md').writeAsString(userMd);
    }
    return synthesis;
  }
}
