import 'dart:async';
import 'package:flutter/services.dart';

/// Native Android Bridge communicating with MainActivity.kt,
/// AgentAccessibilityService.kt, and InboxNotificationListenerService.kt
class PlatformBridgeService {
  static const MethodChannel _accessibilityChannel =
      MethodChannel('com.privateagent/accessibility');
  static const MethodChannel _hardwareChannel =
      MethodChannel('com.privateagent/hardware');
  static const EventChannel _sensorEventChannel =
      EventChannel('com.privateagent/sensor_events');

  Stream<Map<String, dynamic>> get sensorAndPowerEvents {
    return _sensorEventChannel.receiveBroadcastStream().map((event) {
      if (event is Map) {
        return event.map((k, v) => MapEntry(k.toString(), v));
      }
      return <String, dynamic>{};
    });
  }

  Future<bool> isAccessibilityEnabled() async {
    try {
      return await _accessibilityChannel.invokeMethod<bool>('isAccessibilityEnabled') ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> openAccessibilitySettings() async {
    try {
      await _accessibilityChannel.invokeMethod('openAccessibilitySettings');
    } catch (_) {}
  }

  Future<String> dumpScreenTree() async {
    try {
      return await _accessibilityChannel.invokeMethod<String>('dumpScreenTree') ??
          '[Accessibility Service Unavailable]';
    } catch (e) {
      return '[Bridge Error: $e]';
    }
  }

  Future<bool> performTap(double x, double y) async {
    try {
      return await _accessibilityChannel.invokeMethod<bool>('performTap', {'x': x, 'y': y}) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> performSwipe(double x1, double y1, double x2, double y2, {int duration = 350}) async {
    try {
      return await _accessibilityChannel.invokeMethod<bool>('performSwipe', {
            'x1': x1,
            'y1': y1,
            'x2': x2,
            'y2': y2,
            'duration': duration,
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> performInputText(String text) async {
    try {
      return await _accessibilityChannel.invokeMethod<bool>('performInputText', {'text': text}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> performGlobalAction(String action) async {
    try {
      return await _accessibilityChannel.invokeMethod<bool>('performGlobalAction', {'action': action}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  Future<void> startMacroRecording() async {
    try {
      await _accessibilityChannel.invokeMethod('startMacroRecording');
    } catch (_) {}
  }

  Future<List<Map<String, dynamic>>> stopMacroRecording() async {
    try {
      final raw = await _accessibilityChannel.invokeMethod<List<dynamic>>('stopMacroRecording');
      if (raw == null) return [];
      return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  Future<Map<String, dynamic>> getBatteryTelemetry() async {
    try {
      final raw = await _hardwareChannel.invokeMethod<Map<dynamic, dynamic>>('getBatteryTelemetry');
      if (raw != null) {
        return raw.map((k, v) => MapEntry(k.toString(), v));
      }
    } catch (_) {}
    return {
      'percentage': 84,
      'voltageMv': 4180,
      'temperatureC': 31.4,
      'currentMa': 2650.0,
      'watts': 11.1,
      'isCharging': true,
      'medium': 'AC Turbo Flux',
    };
  }

  Future<bool> toggleFlashlight(bool enable) async {
    try {
      return await _hardwareChannel.invokeMethod<bool>('toggleFlashlight', {'enable': enable}) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> adjustVolume(String direction) async {
    try {
      await _hardwareChannel.invokeMethod('adjustVolume', {'direction': direction});
    } catch (_) {}
  }

  Future<void> dispatchMediaKey(String key) async {
    try {
      await _hardwareChannel.invokeMethod('dispatchMediaKey', {'key': key});
    } catch (_) {}
  }

  Future<bool> setAirGestures(bool enabled) async {
    try {
      return await _hardwareChannel.invokeMethod<bool>('setAirGestures', {'enabled': enabled}) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> setSentryMode(bool armed) async {
    try {
      return await _hardwareChannel.invokeMethod<bool>('setSentryMode', {'armed': armed}) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> triggerHapticAlarm() async {
    try {
      await _hardwareChannel.invokeMethod('triggerHapticAlarm');
    } catch (_) {}
  }

  Future<bool> setRedAlertStrobe(bool active) async {
    try {
      return await _hardwareChannel.invokeMethod<bool>('setRedAlertStrobe', {'active': active}) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<String> runOverdriveShell(String command) async {
    try {
      return await _hardwareChannel.invokeMethod<String>('runOverdriveShell', {'command': command}) ?? '';
    } catch (e) {
      return 'Bridge error: $e';
    }
  }
}
