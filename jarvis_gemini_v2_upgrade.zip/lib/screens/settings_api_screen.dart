import 'package:flutter/material.dart';
import '../models/api_settings_model.dart';
import '../services/gemini_ai_service.dart';
import '../services/hermes_service.dart';
import '../services/telegram_service.dart';

/// Multi-Place API Configuration & Hermes Self-Evolution Settings Screen
/// Specifically designed so the operator can enter and switch between different API keys
/// AFTER installing the APK on Android.
class SettingsApiScreen extends StatefulWidget {
  final ApiSettingsModel settings;
  final HermesService hermesService;
  final GeminiAiService aiService;
  final TelegramService telegramService;
  final VoidCallback onSettingsSaved;

  const SettingsApiScreen({
    super.key,
    required this.settings,
    required this.hermesService,
    required this.aiService,
    required this.telegramService,
    required this.onSettingsSaved,
  });

  @override
  State<SettingsApiScreen> createState() => _SettingsApiScreenState();
}

class _SettingsApiScreenState extends State<SettingsApiScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Controllers for API Place 1: Google Gemini
  late TextEditingController _geminiPrimaryKeyCtrl;
  late TextEditingController _geminiBackupKeyCtrl;
  late TextEditingController _geminiModelCtrl;
  late TextEditingController _geminiVisionModelCtrl;
  late TextEditingController _geminiBaseUrlCtrl;

  // Controllers for API Place 2: OpenRouter / OpenAI / DeepSeek
  late TextEditingController _openAiKeyCtrl;
  late TextEditingController _openAiBaseUrlCtrl;
  late TextEditingController _openAiModelCtrl;

  // Controllers for API Place 3: Local Ollama
  late TextEditingController _ollamaUrlCtrl;
  late TextEditingController _ollamaModelCtrl;

  // Controllers for API Place 4: Telegram Remote & Sentry
  late TextEditingController _telegramTokenCtrl;
  late TextEditingController _telegramChatIdCtrl;

  // Controllers for API Place 5: Voice & Operator Profile
  late TextEditingController _voiceApiKeyCtrl;
  late TextEditingController _voiceLocaleCtrl;
  late TextEditingController _operatorTitleCtrl;

  // Hermes Context Editors
  late TextEditingController _soulMdCtrl;
  late TextEditingController _userMdCtrl;
  late TextEditingController _agentMdCtrl;

  String _activeProvider = 'gemini';
  bool _telegramPolling = false;
  bool _alwaysOnWakeWord = false;
  bool _obscureKeys = true;
  String _diagnosticMessage = '';
  bool _testingConnection = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    final s = widget.settings;
    _activeProvider = s.activeProvider;
    _telegramPolling = s.telegramRemotePollingEnabled;
    _alwaysOnWakeWord = s.alwaysOnWakeWord;

    _geminiPrimaryKeyCtrl = TextEditingController(text: s.geminiPrimaryApiKey);
    _geminiBackupKeyCtrl = TextEditingController(text: s.geminiBackupApiKey);
    _geminiModelCtrl = TextEditingController(text: s.geminiModel);
    _geminiVisionModelCtrl = TextEditingController(text: s.geminiVisionModel);
    _geminiBaseUrlCtrl = TextEditingController(text: s.geminiBaseUrl);

    _openAiKeyCtrl = TextEditingController(text: s.openAiCompatibleApiKey);
    _openAiBaseUrlCtrl = TextEditingController(text: s.openAiCompatibleBaseUrl);
    _openAiModelCtrl = TextEditingController(text: s.openAiCompatibleModel);

    _ollamaUrlCtrl = TextEditingController(text: s.ollamaBaseUrl);
    _ollamaModelCtrl = TextEditingController(text: s.ollamaModel);

    _telegramTokenCtrl = TextEditingController(text: s.telegramBotToken);
    _telegramChatIdCtrl = TextEditingController(text: s.telegramChatId);

    _voiceApiKeyCtrl = TextEditingController(text: s.customVoiceTtsApiKey);
    _voiceLocaleCtrl = TextEditingController(text: s.voiceLocale);
    _operatorTitleCtrl = TextEditingController(text: s.operatorTitle);

    _soulMdCtrl = TextEditingController(text: widget.hermesService.soulMd);
    _userMdCtrl = TextEditingController(text: widget.hermesService.userMd);
    _agentMdCtrl = TextEditingController(text: widget.hermesService.agentMd);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _geminiPrimaryKeyCtrl.dispose();
    _geminiBackupKeyCtrl.dispose();
    _geminiModelCtrl.dispose();
    _geminiVisionModelCtrl.dispose();
    _geminiBaseUrlCtrl.dispose();
    _openAiKeyCtrl.dispose();
    _openAiBaseUrlCtrl.dispose();
    _openAiModelCtrl.dispose();
    _ollamaUrlCtrl.dispose();
    _ollamaModelCtrl.dispose();
    _telegramTokenCtrl.dispose();
    _telegramChatIdCtrl.dispose();
    _voiceApiKeyCtrl.dispose();
    _voiceLocaleCtrl.dispose();
    _operatorTitleCtrl.dispose();
    _soulMdCtrl.dispose();
    _userMdCtrl.dispose();
    _agentMdCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveAll() async {
    final s = widget.settings;
    s.activeProvider = _activeProvider;
    s.geminiPrimaryApiKey = _geminiPrimaryKeyCtrl.text.trim();
    s.geminiBackupApiKey = _geminiBackupKeyCtrl.text.trim();
    s.geminiModel = _geminiModelCtrl.text.trim().isEmpty
        ? 'gemini-2.5-flash'
        : _geminiModelCtrl.text.trim();
    s.geminiVisionModel = _geminiVisionModelCtrl.text.trim().isEmpty
        ? 'gemini-2.5-flash'
        : _geminiVisionModelCtrl.text.trim();
    s.geminiBaseUrl = _geminiBaseUrlCtrl.text.trim();

    s.openAiCompatibleApiKey = _openAiKeyCtrl.text.trim();
    s.openAiCompatibleBaseUrl = _openAiBaseUrlCtrl.text.trim();
    s.openAiCompatibleModel = _openAiModelCtrl.text.trim();

    s.ollamaBaseUrl = _ollamaUrlCtrl.text.trim();
    s.ollamaModel = _ollamaModelCtrl.text.trim();

    s.telegramBotToken = _telegramTokenCtrl.text.trim();
    s.telegramChatId = _telegramChatIdCtrl.text.trim();
    s.telegramRemotePollingEnabled = _telegramPolling;

    s.customVoiceTtsApiKey = _voiceApiKeyCtrl.text.trim();
    s.voiceLocale = _voiceLocaleCtrl.text.trim().isEmpty ? 'en-GB' : _voiceLocaleCtrl.text.trim();
    s.operatorTitle = _operatorTitleCtrl.text.trim().isEmpty ? 'Sir' : _operatorTitleCtrl.text.trim();
    s.alwaysOnWakeWord = _alwaysOnWakeWord;

    await s.save();
    await widget.hermesService.saveFiles(
      newSoul: _soulMdCtrl.text,
      newUser: _userMdCtrl.text,
      newAgent: _agentMdCtrl.text,
    );
    widget.aiService.updateSettings(s);
    widget.telegramService.updateSettings(s);
    widget.onSettingsSaved();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Color(0xFF00E676),
          content: Text(
            '⚡ All J.A.R.V.I.S. API Slots & Hermes Context Matrix Saved.',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
      );
    }
  }

  Future<void> _testGeminiConnection() async {
    await _saveAll();
    setState(() {
      _testingConnection = true;
      _diagnosticMessage = 'Pinging Google Gemini neural core...';
    });
    final reply = await widget.aiService.generateSingleCompletion(
      prompt: 'Reply in 1 short sentence confirming J.A.R.V.I.S. Gemini core is online.',
    );
    setState(() {
      _testingConnection = false;
      _diagnosticMessage = reply;
    });
  }

  @override
  Widget build(BuildContext context) {
    const cyan = Color(0xFF00E5FF);
    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B1324),
        title: const Text(
          '⚡ MULTI-SLOT API & HERMES HUB',
          style: TextStyle(color: cyan, fontSize: 15, fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
        actions: [
          IconButton(
            tooltip: _obscureKeys ? 'Show API Keys' : 'Hide API Keys',
            icon: Icon(_obscureKeys ? Icons.visibility_off : Icons.visibility, color: cyan),
            onPressed: () => setState(() => _obscureKeys = !_obscureKeys),
          ),
          TextButton.icon(
            onPressed: _saveAll,
            icon: const Icon(Icons.save, color: Color(0xFF00E676), size: 18),
            label: const Text(
              'SAVE',
              style: TextStyle(color: Color(0xFF00E676), fontWeight: FontWeight.bold),
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: cyan,
          labelColor: cyan,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(icon: Icon(Icons.vpn_key_outlined), text: '5 API SLOTS & KEYS'),
            Tab(icon: Icon(Icons.psychology_outlined), text: 'HERMES (SOUL / USER / AGENT)'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildApiSlotsTab(cyan),
          _buildHermesEditorTab(cyan),
        ],
      ),
    );
  }

  Widget _buildApiSlotsTab(Color cyan) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Active Provider Selector Card
        _sectionCard(
          title: 'ACTIVE PRIMARY AI ENGINE',
          subtitle: 'Select which API slot powers J.A.R.V.I.S. cognition & Agent Mode',
          borderColor: cyan,
          children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'gemini', label: Text('Google Gemini')),
                ButtonSegment(value: 'openai_compatible', label: Text('OpenRouter / DeepSeek')),
                ButtonSegment(value: 'ollama', label: Text('Local Ollama')),
              ],
              selected: {_activeProvider},
              onSelectionChanged: (s) => setState(() => _activeProvider = s.first),
            ),
          ],
        ),
        const SizedBox(height: 14),

        // API PLACE 1: Google Gemini Primary & Vision Slot
        _sectionCard(
          title: 'API PLACE 1 // UNIVERSAL ANY-KEY (AUTO-DETECT) OR GEMINI',
          subtitle: 'Paste ANY key here (Gemini AIza..., OpenRouter sk-or-..., Groq gsk_..., OpenAI/DeepSeek sk-...) — or leave blank for Keyless Mode!',
          borderColor: const Color(0xFF00E5FF),
          children: [
            _apiField(
              label: 'Universal Any-Provider API Key (or Primary Gemini Key)',
              hint: 'AIzaSy...',
              controller: _geminiPrimaryKeyCtrl,
              obscure: _obscureKeys,
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Backup / Secondary Gemini API Key (Auto-Failover)',
              hint: 'AIzaSy... (Optional second key)',
              controller: _geminiBackupKeyCtrl,
              obscure: _obscureKeys,
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _apiField(
                    label: 'Gemini Chat/Agent Model',
                    hint: 'gemini-2.5-flash',
                    controller: _geminiModelCtrl,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _apiField(
                    label: 'Gemini Optical Vision Model',
                    hint: 'gemini-2.5-flash',
                    controller: _geminiVisionModelCtrl,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                for (final preset in ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'])
                  ActionChip(
                    backgroundColor: const Color(0xFF102038),
                    label: Text(preset, style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 11)),
                    onPressed: () => setState(() {
                      _geminiModelCtrl.text = preset;
                      _geminiVisionModelCtrl.text = preset;
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Gemini Base Endpoint URL',
              hint: 'https://generativelanguage.googleapis.com/v1beta',
              controller: _geminiBaseUrlCtrl,
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00E5FF).withOpacity(0.18),
                foregroundColor: const Color(0xFF00E5FF),
              ),
              onPressed: _testingConnection ? null : _testGeminiConnection,
              icon: const Icon(Icons.bolt),
              label: Text(_testingConnection ? 'TESTING GEMINI LINK...' : 'SAVE & TEST GEMINI API KEY'),
            ),
            if (_diagnosticMessage.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black45,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white24),
                ),
                child: Text(
                  _diagnosticMessage,
                  style: const TextStyle(color: Color(0xFF00E676), fontSize: 12),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 14),

        // API PLACE 2: OpenRouter / OpenAI / DeepSeek / NVIDIA NIM Slot
        _sectionCard(
          title: 'API PLACE 2 // OPENROUTER / OPENAI / DEEPSEEK',
          subtitle: 'Secondary cloud LLM slot for OpenAI-compatible endpoints',
          borderColor: const Color(0xFFBA68C8),
          children: [
            _apiField(
              label: 'OpenRouter / OpenAI / DeepSeek API Key',
              hint: 'sk-or-v1-... or sk-...',
              controller: _openAiKeyCtrl,
              obscure: _obscureKeys,
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Base URL (OpenRouter / DeepSeek / OpenAI / NVIDIA NIM)',
              hint: 'https://openrouter.ai/api/v1',
              controller: _openAiBaseUrlCtrl,
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Model Name',
              hint: 'deepseek/deepseek-chat or gpt-4o-mini',
              controller: _openAiModelCtrl,
            ),
          ],
        ),
        const SizedBox(height: 14),

        // API PLACE 3: Local Offline Ollama Slot
        _sectionCard(
          title: 'API PLACE 3 // LOCAL OFFLINE OLLAMA INSTANCE',
          subtitle: '100% offline local inference via Termux or LAN Ollama server',
          borderColor: const Color(0xFF00E676),
          children: [
            _apiField(
              label: 'Ollama Server URL',
              hint: 'http://127.0.0.1:11434',
              controller: _ollamaUrlCtrl,
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Local Ollama Model Tag',
              hint: 'llama3.2 or qwen2.5',
              controller: _ollamaModelCtrl,
            ),
          ],
        ),
        const SizedBox(height: 14),

        // API PLACE 4: Telegram Bot Remote Terminal & Sentry Watchdog
        _sectionCard(
          title: 'API PLACE 4 // TELEGRAM REMOTE TERMINAL & SENTRY BOT',
          subtitle: 'Control J.A.R.V.I.S. remotely & receive Sentry breach alerts via Telegram',
          borderColor: const Color(0xFFFFB300),
          children: [
            _apiField(
              label: 'Telegram Bot Token (@BotFather)',
              hint: '123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ',
              controller: _telegramTokenCtrl,
              obscure: _obscureKeys,
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Authorized Telegram Chat ID',
              hint: 'e.g. 987654321',
              controller: _telegramChatIdCtrl,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: const Color(0xFFFFB300),
              title: const Text(
                'Enable Telegram Long-Polling Remote Terminal',
                style: TextStyle(color: Colors.white, fontSize: 13),
              ),
              subtitle: const Text(
                'Accept /status, /screenshot, /cancel, and remote task commands',
                style: TextStyle(color: Colors.white54, fontSize: 11),
              ),
              value: _telegramPolling,
              onChanged: (v) => setState(() => _telegramPolling = v),
            ),
          ],
        ),
        const SizedBox(height: 14),

        // API PLACE 5: Studio Voice, Wake Word & Operator Identity
        _sectionCard(
          title: 'API PLACE 5 // VOICE TTS API & OPERATOR IDENTITY',
          subtitle: 'Wake-word configuration, operator title, and optional custom Voice API key',
          borderColor: const Color(0xFFFF1744),
          children: [
            Row(
              children: [
                Expanded(
                  child: _apiField(
                    label: 'Operator Honorific Title',
                    hint: 'Sir / Boss / Commander',
                    controller: _operatorTitleCtrl,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _apiField(
                    label: 'Neural TTS Voice Locale',
                    hint: 'en-GB',
                    controller: _voiceLocaleCtrl,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            _apiField(
              label: 'Optional Custom Voice / ElevenLabs TTS API Key',
              hint: 'Optional external voice synthesis key',
              controller: _voiceApiKeyCtrl,
              obscure: _obscureKeys,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: const Color(0xFF00E676),
              title: const Text(
                'Always-On Wake Word Receptor ("Hey Jarvis")',
                style: TextStyle(color: Colors.white, fontSize: 13),
              ),
              subtitle: const Text(
                'Keeps 7.5s continuation window active for hands-free desk operation',
                style: TextStyle(color: Colors.white54, fontSize: 11),
              ),
              value: _alwaysOnWakeWord,
              onChanged: (v) => setState(() => _alwaysOnWakeWord = v),
            ),
          ],
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildHermesEditorTab(Color cyan) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionCard(
          title: '1. SOUL.md — CORE IDENTITY & CONSTITUTION',
          subtitle: 'Defines J.A.R.V.I.S. ethos, loyalty, demeanor, and safety guardrails',
          borderColor: cyan,
          children: [
            _markdownEditor(_soulMdCtrl),
          ],
        ),
        const SizedBox(height: 14),
        _sectionCard(
          title: '2. USER.md — OPERATOR HABITS & LEARNED FACTS',
          subtitle: 'Synchronized automatically when you trigger "SELF EVOLVE"',
          borderColor: const Color(0xFF00E676),
          children: [
            _markdownEditor(_userMdCtrl),
          ],
        ),
        const SizedBox(height: 14),
        _sectionCard(
          title: '3. AGENT.md — PROTOCOLS & RECORDED MACRO SKILLS',
          subtitle: 'Stores Observe-Think-Act rules and zero-token UI replay macros',
          borderColor: const Color(0xFFBA68C8),
          children: [
            _markdownEditor(_agentMdCtrl),
          ],
        ),
      ],
    );
  }

  Widget _sectionCard({
    required String title,
    required String subtitle,
    required Color borderColor,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0C1629),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor.withOpacity(0.45), width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: borderColor,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            style: const TextStyle(color: Colors.white60, fontSize: 11),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _apiField({
    required String label,
    required String hint,
    required TextEditingController controller,
    bool obscure = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70, fontSize: 12),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
        filled: true,
        fillColor: const Color(0xFF070D19),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.white24),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF00E5FF)),
        ),
      ),
    );
  }

  Widget _markdownEditor(TextEditingController ctrl) {
    return TextField(
      controller: ctrl,
      maxLines: 8,
      style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 12),
      decoration: InputDecoration(
        filled: true,
        fillColor: const Color(0xFF070D19),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}
