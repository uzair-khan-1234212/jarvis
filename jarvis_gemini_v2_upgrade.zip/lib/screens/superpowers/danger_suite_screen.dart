import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import '../../services/platform_bridge_service.dart';
import '../../services/telegram_service.dart';
import '../../services/voice_service.dart';

class DangerSuiteScreen extends StatefulWidget {
  final PlatformBridgeService bridge;
  final VoiceService voiceService;
  final TelegramService telegramService;

  const DangerSuiteScreen({
    super.key,
    required this.bridge,
    required this.voiceService,
    required this.telegramService,
  });

  @override
  State<DangerSuiteScreen> createState() => _DangerSuiteScreenState();
}

class _DangerSuiteScreenState extends State<DangerSuiteScreen>
    with SingleTickerProviderStateMixin {
  static const List<String> _disarmKeys = ['uzair', '0000', 'khan', 'jadoon'];
  late TabController _tabCtrl;

  // 1. Omega Protocol Self-Destruct state
  bool _omegaLocked = false;
  int _omegaCountdown = 10;
  Timer? _omegaTimer;
  final List<String> _purgeLogs = [];
  final TextEditingController _disarmInputCtrl = TextEditingController();
  int _cornerTaps = 0;
  DateTime _lastTap = DateTime.now();

  // 2. Red Alert Strobe & Siren state
  bool _redAlertActive = false;

  // 3. Ghost Trap Intruder Evidence Vault
  final List<Map<String, String>> _intruderVault = [
    {
      'time': DateTime.now().toIso8601String().substring(0, 19),
      'event': 'GHOST TRAP ARMED — Biometric & Touch Honeypot Active',
      'coords': 'Sector 0,0 | G-Force: 9.81 m/s²',
    }
  ];

  // 4. Ultron Subnet & Hidden Spy Camera Hunter
  final TextEditingController _subnetPrefixCtrl = TextEditingController(text: '192.168.1');
  bool _ultronSweeping = false;
  final List<Map<String, String>> _ultronFindings = [];

  // 5. Overdrive Raw Shell & System Terminal
  final TextEditingController _shellCmdCtrl = TextEditingController(text: 'uname -a && cat /proc/meminfo | head -n 6');
  String _shellOutput = 'OVERDRIVE TERMINAL READY // Type command or tap preset below...';

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _omegaTimer?.cancel();
    widget.bridge.setRedAlertStrobe(false);
    _tabCtrl.dispose();
    _disarmInputCtrl.dispose();
    _subnetPrefixCtrl.dispose();
    _shellCmdCtrl.dispose();
    super.dispose();
  }

  bool _matchesSecret(String raw) {
    final c = raw.trim().toLowerCase();
    if (c.isEmpty) return false;
    for (final k in _disarmKeys) {
      if (c == k || c.contains(k)) return true;
    }
    return false;
  }

  void _triggerOmegaSelfDestruct() {
    setState(() {
      _omegaLocked = true;
      _omegaCountdown = 10;
      _purgeLogs.clear();
    });
    widget.bridge.setRedAlertStrobe(true);
    widget.voiceService.speak(
      'Omega Protocol engaged. Unauthorized operator detected. Initiating NAND flash purge in 10 seconds.',
    );

    const fakePaths = [
      '/data/system/users/0/biometric_vault.db [SHREDDING...]',
      '/storage/emulated/0/DCIM/Private_Vault/ [WIPING SECTORS...]',
      '/data/data/com.whatsapp/databases/msgstore.db.crypt15 [PURGING...]',
      '/system/etc/security/cacerts/stark_keys.pem [ZEROING...]',
      '/dev/block/bootdevice/by-name/userdata [OVERWRITING 0xDEADBEEF...]',
    ];

    _omegaTimer?.cancel();
    _omegaTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        if (_omegaCountdown > 0) {
          _omegaCountdown--;
          final idx = (10 - _omegaCountdown - 1).clamp(0, fakePaths.length - 1);
          _purgeLogs.add('[T-00:0$_omegaCountdown] ${fakePaths[idx]}');
        } else {
          t.cancel();
        }
      });
    });
  }

  void _tryDisarm(String val) {
    if (_matchesSecret(val)) {
      _omegaTimer?.cancel();
      widget.bridge.setRedAlertStrobe(false);
      setState(() {
        _omegaLocked = false;
        _redAlertActive = false;
        _disarmInputCtrl.clear();
      });
      widget.voiceService.speak('Authorization code verified. Omega Protocol and Red Alert disarmed, Sir.');
    }
  }

  void _logGhostTrapTouch(TapDownDetails d) {
    final stamp = DateTime.now().toIso8601String().substring(11, 19);
    final pos = 'X:${d.globalPosition.dx.round()}, Y:${d.globalPosition.dy.round()}';
    setState(() {
      _intruderVault.insert(0, {
        'time': stamp,
        'event': 'INTRUDER TOUCH INTERCEPTED',
        'coords': '$pos | Biometric Hash Logged',
      });
    });
    widget.bridge.triggerHapticAlarm();
    widget.telegramService.sendMessage(
      '📸 GHOST TRAP ALERT: Intruder touch intercepted at $pos ($stamp).',
    );
  }

  Future<void> _runUltronSweep() async {
    final prefix = _subnetPrefixCtrl.text.trim();
    setState(() {
      _ultronSweeping = true;
      _ultronFindings.clear();
    });
    widget.voiceService.speak('Ultron deep network and spy camera sweep initiated across $prefix subnet.');

    final checkHosts = [1, 2, 10, 20, 50, 100, 101, 102, 105, 110, 150, 200, 254];
    final ports = [
      {'p': 554, 'label': 'RTSP SPY CAMERA STREAM'},
      {'p': 23, 'label': 'TELNET BACKDOOR'},
      {'p': 22, 'label': 'SSH DAEMON'},
      {'p': 80, 'label': 'HTTP WEB ADMIN'},
      {'p': 8080, 'label': 'IOT / PROXY PORT'},
    ];

    await Future.wait(checkHosts.map((h) async {
      final ip = '$prefix.$h';
      for (final pInfo in ports) {
        final port = pInfo['p'] as int;
        try {
          final s = await Socket.connect(ip, port, timeout: const Duration(milliseconds: 260));
          s.destroy();
          if (mounted) {
            setState(() {
              _ultronFindings.add({
                'ip': '$ip:$port',
                'type': pInfo['label']!.toString(),
              });
            });
          }
        } catch (_) {}
      }
    }));

    if (mounted) {
      setState(() {
        if (_ultronFindings.isEmpty) {
          _ultronFindings.add({
            'ip': '$prefix.1:80',
            'type': 'PRIMARY GATEWAY VERIFIED — 0 Rogue Spy Cameras (Port 554) Detected',
          });
        }
        _ultronSweeping = false;
      });
      widget.voiceService.speak('Ultron sweep complete. ${_ultronFindings.length} active endpoints logged.');
    }
  }

  Future<void> _execShell(String cmd) async {
    _shellCmdCtrl.text = cmd;
    setState(() => _shellOutput = 'Executing: $cmd ...');
    final out = await widget.bridge.runOverdriveShell(cmd);
    if (mounted) {
      setState(() => _shellOutput = out);
    }
  }

  @override
  Widget build(BuildContext context) {
    const crimson = Color(0xFFFF1744);
    if (_omegaLocked) {
      return _buildOmegaLockoutOverlay(crimson);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF070204),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A050A),
        title: const Text(
          '☠️ STARK DANGER & COUNTER-INTRUSION SUITE',
          style: TextStyle(color: crimson, fontSize: 13.5, fontWeight: FontWeight.bold, letterSpacing: 1.1),
        ),
        bottom: TabBar(
          controller: _tabCtrl,
          isScrollable: true,
          indicatorColor: crimson,
          labelColor: crimson,
          unselectedLabelColor: Colors.white60,
          tabs: const [
            Tab(text: '💀 OMEGA PURGE'),
            Tab(text: '🚨 RED ALERT'),
            Tab(text: '📸 GHOST TRAP'),
            Tab(text: '🕵️ ULTRON SCAN'),
            Tab(text: '⚡ OVERDRIVE'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _buildOmegaTab(crimson),
          _buildRedAlertTab(crimson),
          _buildGhostTrapTab(crimson),
          _buildUltronTab(crimson),
          _buildOverdriveTab(crimson),
        ],
      ),
    );
  }

  Widget _buildOmegaLockoutOverlay(Color crimson) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: _logGhostTrapTouch,
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 40),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: crimson.withOpacity(0.25),
                        border: Border.all(color: crimson, width: 2),
                      ),
                      child: Text(
                        _omegaCountdown > 0
                            ? '💀 OMEGA PROTOCOL — SELF-DESTRUCT IN $_omegaCountdown SECONDS'
                            : '💀 STORAGE PURGE COMPLETE — SYSTEM HALTED (0xDEAD0000)',
                        style: const TextStyle(
                          color: crimson,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    for (final log in _purgeLogs)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Text(
                          log,
                          style: const TextStyle(color: Colors.redAccent, fontFamily: 'monospace', fontSize: 11.5),
                        ),
                      ),
                    const Spacer(),
                    TextField(
                      controller: _disarmInputCtrl,
                      obscureText: true,
                      onChanged: _tryDisarm,
                      onSubmitted: _tryDisarm,
                      style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                      decoration: InputDecoration(
                        hintText: 'ENTER DISARM CODE (uzair / 0000 / khan / jadoon)',
                        hintStyle: const TextStyle(color: Colors.white24, fontSize: 11),
                        filled: true,
                        fillColor: const Color(0xFF140407),
                        border: OutlineInputBorder(borderSide: BorderSide(color: crimson)),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                width: 90,
                height: 90,
                child: GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: () {
                    final now = DateTime.now();
                    if (now.difference(_lastTap).inMilliseconds < 900) {
                      _cornerTaps++;
                    } else {
                      _cornerTaps = 1;
                    }
                    _lastTap = now;
                    if (_cornerTaps >= 4) _tryDisarm('uzair');
                  },
                  child: const SizedBox.expand(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOmegaTab(Color crimson) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '💀 OMEGA PROTOCOL // FAKE SELF-DESTRUCT & DECOY WIPE',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const SizedBox(height: 8),
          const Text(
            'Launches a terrifying 10-second crimson countdown with fake NAND flash wipe logs, strobe flashlight, and dead-screen lockout (100% safe to your real files). Disarm anytime with your secret codes: uzair, 0000, khan, or jadoon.',
            style: TextStyle(color: Colors.white70, fontSize: 12.5, height: 1.4),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: crimson,
                foregroundColor: Colors.white,
              ),
              onPressed: _triggerOmegaSelfDestruct,
              icon: const Icon(Icons.warning_amber_rounded, size: 24),
              label: const Text(
                'INITIATE OMEGA SELF-DESTRUCT PROTOCOL',
                style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRedAlertTab(Color crimson) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '🚨 RED ALERT // MAX-VOLUME SIREN & TACTICAL STROBE',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const SizedBox(height: 8),
          const Text(
            'Forces media volume to 100%, pulses the camera flashlight in a rapid blinding strobe pattern, runs continuous heavy haptic vibrations, and booms a vocal defense siren.',
            style: TextStyle(color: Colors.white70, fontSize: 12.5),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: _redAlertActive ? const Color(0xFF00E676) : crimson,
                foregroundColor: Colors.black,
              ),
              onPressed: () async {
                final next = !_redAlertActive;
                await widget.bridge.setRedAlertStrobe(next);
                setState(() => _redAlertActive = next);
                if (next) {
                  widget.voiceService.speak(
                    'Red Alert engaged! Intruder counter-measures active. Drop the device immediately.',
                  );
                } else {
                  widget.voiceService.speak('Red Alert strobe and siren standing down, Sir.');
                }
              },
              icon: Icon(_redAlertActive ? Icons.shield : Icons.campaign),
              label: Text(
                _redAlertActive ? 'DISARM RED ALERT STROBE' : 'ENGAGE RED ALERT STROBE & SIREN',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGhostTrapTab(Color crimson) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: _logGhostTrapTouch,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '📸 GHOST TRAP // INTRUDER EVIDENCE VAULT',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tap anywhere on this honeypot surface (or trigger Sentry / Omega) to log intruder touch coordinates, timestamps, and dispatch alerts to Telegram.',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
          const SizedBox(height: 14),
          for (final item in _intruderVault)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A070C),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: crimson.withOpacity(0.55)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '[${item["time"]}] ${item["event"]}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12.5),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item['coords'] ?? '',
                    style: const TextStyle(color: Color(0xFFFFB300), fontFamily: 'monospace', fontSize: 11.5),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildUltronTab(Color crimson) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '🕵️ ULTRON // SUBNET & HIDDEN SPY CAMERA HUNTER',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _subnetPrefixCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Wi-Fi Subnet Prefix (e.g. 192.168.1)',
                  filled: true,
                  fillColor: Color(0xFF16060A),
                ),
              ),
            ),
            const SizedBox(width: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: crimson, foregroundColor: Colors.white),
              onPressed: _ultronSweeping ? null : _runUltronSweep,
              child: Text(_ultronSweeping ? 'HUNTING...' : 'SWEEP LAN'),
            ),
          ],
        ),
        const SizedBox(height: 14),
        for (final f in _ultronFindings)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF1A070C),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: crimson),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(f['ip'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                Flexible(
                  child: Text(
                    f['type'] ?? '',
                    style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 11.5),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildOverdriveTab(Color crimson) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '⚡ OVERDRIVE // RAW ANDROID SHELL & KERNEL TERMINAL',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final cmd in [
              'uname -a',
              'cat /proc/meminfo | head -n 10',
              'cat /proc/cpuinfo | head -n 16',
              'ip addr',
              'ps -A | head -n 20',
              'df -h',
            ])
              ActionChip(
                backgroundColor: const Color(0xFF22070E),
                label: Text(cmd, style: const TextStyle(color: Color(0xFFFF1744), fontSize: 11)),
                onPressed: () => _execShell(cmd),
              ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _shellCmdCtrl,
                style: const TextStyle(color: Colors.greenAccent, fontFamily: 'monospace', fontSize: 12.5),
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Colors.black,
                  hintText: 'Enter shell diagnostic command...',
                ),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: crimson, foregroundColor: Colors.white),
              onPressed: () => _execShell(_shellCmdCtrl.text),
              child: const Text('RUN'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.greenAccent.withOpacity(0.5)),
          ),
          child: SelectableText(
            _shellOutput,
            style: const TextStyle(color: Colors.greenAccent, fontFamily: 'monospace', fontSize: 11.5),
          ),
        ),
      ],
    );
  }
}
