import 'package:flutter/material.dart';
import '../../services/platform_bridge_service.dart';
import '../../services/voice_service.dart';

class CodeBlackScreen extends StatefulWidget {
  final PlatformBridgeService bridge;
  final VoiceService voiceService;

  const CodeBlackScreen({
    super.key,
    required this.bridge,
    required this.voiceService,
  });

  @override
  State<CodeBlackScreen> createState() => _CodeBlackScreenState();
}

class _CodeBlackScreenState extends State<CodeBlackScreen> {
  static const List<String> _secretCodes = ['uzair', '0000', 'khan', 'jadoon'];
  final TextEditingController _codeCtrl = TextEditingController();
  int _tamperViolations = 0;
  int _cornerTapCount = 0;
  DateTime _lastCornerTap = DateTime.now();

  void _checkDisarmCode(String value) {
    final v = value.trim().toLowerCase();
    for (final secret in _secretCodes) {
      if (v == secret || v.contains(secret)) {
        widget.bridge.setRedAlertStrobe(false);
        widget.voiceService.speak('Identity verified. Standing down Code Black, Sir.');
        Navigator.of(context).pop();
        return;
      }
    }
  }

  void _onUnauthorizedTouch() {
    setState(() => _tamperViolations++);
    widget.bridge.triggerHapticAlarm();
    widget.voiceService.speak(
      'Tamper violation $_tamperViolations detected. Intruder biometrics logged.',
    );
  }

  void _onHiddenDisarmCornerTap() {
    final now = DateTime.now();
    if (now.difference(_lastCornerTap).inMilliseconds < 900) {
      _cornerTapCount++;
    } else {
      _cornerTapCount = 1;
    }
    _lastCornerTap = now;
    if (_cornerTapCount >= 4) {
      widget.bridge.setRedAlertStrobe(false);
      widget.voiceService.speak('Override verified. Code Black standing down.');
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    const crimson = Color(0xFFFF1744);
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _onUnauthorizedTouch,
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 36),
                    Container(
                      padding: const EdgeInsets.all(10),
                      color: crimson.withOpacity(0.2),
                      child: const Text(
                        '*** KERNEL PANIC — FATAL EXCEPTION: SIGSEGV AT 0xDEADBEEF ***',
                        style: TextStyle(
                          color: crimson,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'CPU 0: PID 1337 Comm: stark_sec_daemon Tainted: G   W   6.6.30-android15\n'
                      'Hardware name: STARK CYBERNETIC DEFENSE NODE\n'
                      '0xDEAD0000: 45 78 65 63 75 74 69 6e 67 20 43 6f 64 65 20 42',
                      style: TextStyle(
                        color: Colors.greenAccent,
                        fontFamily: 'monospace',
                        fontSize: 11,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        border: Border.all(color: crimson, width: 2),
                        color: crimson.withOpacity(0.14),
                      ),
                      child: Text(
                        '🚨 TAMPER VIOLATIONS: [$_tamperViolations]\nTRANSMITTING INTRUDER BIOMETRICS TO DEFENSE COMMAND',
                        style: const TextStyle(
                          color: crimson,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    const Spacer(),
                    TextField(
                      controller: _codeCtrl,
                      obscureText: true,
                      onChanged: _checkDisarmCode,
                      onSubmitted: _checkDisarmCode,
                      style: const TextStyle(color: Colors.redAccent, fontFamily: 'monospace'),
                      decoration: InputDecoration(
                        hintText: 'KERNEL OVERRIDE KEY (uzair / 0000 / khan / jadoon)',
                        hintStyle: const TextStyle(color: Colors.white24, fontSize: 11),
                        filled: true,
                        fillColor: const Color(0xFF0F0406),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: crimson.withOpacity(0.5)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                width: 90,
                height: 90,
                child: GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: _onHiddenDisarmCornerTap,
                  child: const SizedBox.expand(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
