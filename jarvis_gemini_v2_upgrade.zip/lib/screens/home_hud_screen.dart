import 'dart:async';
import 'package:flutter/material.dart';
class MarkdownStyleSheet {
  final TextStyle? p, strong, h1, h2, code;
  const MarkdownStyleSheet({this.p, this.strong, this.h1, this.h2, this.code});
}
class MarkdownBody extends StatelessWidget {
  final String data;
  final MarkdownStyleSheet? styleSheet;
  const MarkdownBody({super.key, required this.data, this.styleSheet});
  @override
  Widget build(BuildContext context) => SelectableText(data, style: styleSheet?.p ?? const TextStyle(color: Colors.white));
}
class Uuid { const Uuid(); String v4() => DateTime.now().microsecondsSinceEpoch.toString(); }
import '../models/api_settings_model.dart';
import '../models/jarvis_state.dart';
import '../services/gemini_ai_service.dart';
import '../services/hermes_service.dart';
import '../services/platform_bridge_service.dart';
import '../services/task_executor_service.dart';
import '../services/telegram_service.dart';
import '../services/voice_service.dart';
import '../widgets/arc_reactor_hud.dart';
import 'settings_api_screen.dart';
import 'superpowers/air_gestures_modals.dart';
import 'superpowers/airspace_radar_screen.dart';
import 'superpowers/brain_dump_dialog.dart';
import 'superpowers/code_black_screen.dart';
import 'superpowers/danger_suite_screen.dart';
import 'superpowers/network_audit_screen.dart';
import 'superpowers/optical_solver_screen.dart';
import 'superpowers/polyglot_diplomat_screen.dart';

class HomeHudScreen extends StatefulWidget {
  final ApiSettingsModel settings;
  final HermesService hermesService;

  const HomeHudScreen({
    super.key,
    required this.settings,
    required this.hermesService,
  });

  @override
  State<HomeHudScreen> createState() => _HomeHudScreenState();
}

class _HomeHudScreenState extends State<HomeHudScreen> {
  final Uuid _uuid = const Uuid();
  final PlatformBridgeService _bridge = PlatformBridgeService();
  late GeminiAiService _aiService;
  late VoiceService _voiceService;
  late TaskExecutorService _taskExecutor;
  late TelegramService _telegramService;

  JarvisAuraState _auraState = JarvisAuraState.standbyIdle;
  JarvisOperationalMode _operationalMode = JarvisOperationalMode.jarvisVoiceHud;
  HudProjectionStyle _projectionStyle = HudProjectionStyle.arcReactorCore;

  double _soundLevel = 0.0;
  bool _alwaysOnListening = false;
  bool _airGesturesEnabled = false;
  bool _sentryArmed = false;

  final List<ChatMessage> _messages = [];
  final List<String> _agentLogs = [];
  final TextEditingController _promptCtrl = TextEditingController();
  final TextEditingController _agentGoalCtrl = TextEditingController(
    text: 'Open Settings and check Wi-Fi status',
  );
  StreamSubscription<Map<String, dynamic>>? _sensorSub;

  @override
  void initState() {
    super.initState();
    _alwaysOnListening = widget.settings.alwaysOnWakeWord;
    _aiService = GeminiAiService(settings: widget.settings);
    _taskExecutor = TaskExecutorService(aiService: _aiService, bridge: _bridge);

    _voiceService = VoiceService(
      onTranscript: _handleVoiceTranscript,
      onSoundLevelChanged: (rms) {
        if (mounted) setState(() => _soundLevel = rms);
      },
      onSpeakingStateChanged: (speaking) {
        if (!mounted) return;
        setState(() {
          if (_sentryArmed && _auraState == JarvisAuraState.tacticalLockdown) return;
          _auraState = speaking
              ? JarvisAuraState.speakingVocalizing
              : (_voiceService.isListening
                  ? JarvisAuraState.activeListening
                  : JarvisAuraState.standbyIdle);
        });
      },
    );

    _voiceService.alwaysOnMode = _alwaysOnListening;
    _voiceService.initialize(
      locale: widget.settings.voiceLocale,
      rate: widget.settings.speechRate,
      pitch: widget.settings.speechPitch,
    );

    _telegramService = TelegramService(
      settings: widget.settings,
      onRemoteCommandReceived: _handleTelegramCommand,
    );
    _telegramService.updateSettings(widget.settings);

    _sensorSub = _bridge.sensorAndPowerEvents.listen(_handleHardwareEvent);

    _messages.add(ChatMessage(
      id: _uuid.v4(),
      role: 'assistant',
      content: 'All J.A.R.V.I.S. v2.0 cybernetic systems and **Danger Suite** protocols are online, ${widget.settings.operatorTitle}. Running in **Universal / Keyless Ready Mode** (add any provider key in Settings ⚙️ anytime, or tap **☠️ Danger Zone** below).',
    ));
  }

  @override
  void dispose() {
    _sensorSub?.cancel();
    _voiceService.dispose();
    _telegramService.stopPolling();
    _promptCtrl.dispose();
    _agentGoalCtrl.dispose();
    super.dispose();
  }

  void _handleHardwareEvent(Map<String, dynamic> event) {
    final type = event['type']?.toString() ?? '';
    if (type == 'POWER_STATE_CHANGED' && event['connected'] == true) {
      final telemetry = (event['telemetry'] as Map?)?.map((k, v) => MapEntry(k.toString(), v)) ??
          <String, dynamic>{};
      final watts = (telemetry['watts'] as num?)?.toStringAsFixed(1) ?? '18.5';
      final pct = telemetry['percentage'] ?? 80;
      final temp = telemetry['temperatureC'] ?? 31.4;
      _voiceService.speak(
        'Arc reactor coupled, ${widget.settings.operatorTitle}. Energy intake active at $watts Watts. Power cells at $pct percent, core temperature steady at $temp degrees Celsius.',
      );
      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => ArcReactorTelemetryDialog(telemetry: telemetry),
        );
      }
    } else if (type == 'SENTRY_BREACH' && _sentryArmed) {
      setState(() => _auraState = JarvisAuraState.tacticalLockdown);
      _voiceService.speak(
        'Security violation detected. Spatial coordinates and telemetry logged and dispatched.',
      );
      _telegramService.sendMessage(
        '🚨 J.A.R.V.I.S. SENTRY BREACH DETECTED! Motion spike magnitude: ${event["magnitude"]} at ${DateTime.now().toIso8601String()}.',
      );
    }
  }

  Future<String> _handleTelegramCommand(String cmd) async {
    final clean = cmd.trim();
    if (clean == '/status') {
      final bat = await _bridge.getBatteryTelemetry();
      final a11y = await _bridge.isAccessibilityEnabled();
      return '⚡ J.A.R.V.I.S. Telemetry: Battery ${bat["percentage"]}% (${bat["medium"]}) | Accessibility Agent: ${a11y ? "ONLINE" : "OFFLINE"} | Active Model: ${widget.settings.geminiModel}';
    } else if (clean == '/cancel' || clean == '/stop') {
      _taskExecutor.cancelAgent();
      return '🛑 Autonomous task execution terminated.';
    } else {
      final reply = await _aiService.generateSingleCompletion(prompt: clean);
      return '🤖 J.A.R.V.I.S.: $reply';
    }
  }

  void _handleVoiceTranscript(String transcript, bool isFinal) {
    if (!isFinal || transcript.trim().isEmpty) return;
    final lower = transcript.toLowerCase();

    // Voice shortcuts for self-evolution & always-on mode
    if (lower.contains('self evolve') || lower.contains('evolve context') || lower.contains('update your memory')) {
      _triggerSelfEvolve();
      return;
    }
    if (lower.contains('activate sentry') || lower.contains('sentry protocol')) {
      _toggleSentryMode(true);
      return;
    }
    if (lower.contains('code black')) {
      _openCodeBlack();
      return;
    }

    _sendPrompt(transcript, speakReply: true);
  }

  Future<void> _sendPrompt(String promptText, {bool speakReply = false}) async {
    final trimmed = promptText.trim();
    if (trimmed.isEmpty) return;
    _promptCtrl.clear();

    setState(() {
      _messages.add(ChatMessage(id: _uuid.v4(), role: 'user', content: trimmed));
      _auraState = JarvisAuraState.computingThinking;
    });

    final assistantMsg = ChatMessage(
      id: _uuid.v4(),
      role: 'assistant',
      content: '...',
      providerBadge: widget.settings.activeProvider.toUpperCase(),
    );
    setState(() => _messages.add(assistantMsg));

    final sysInstruction = _aiService.buildSystemInstruction(
      widget.hermesService.soulMd,
      widget.hermesService.userMd,
      widget.hermesService.agentMd,
    );

    String finalResponse = '';
    await for (final partial in _aiService.streamChatResponse(
      history: _messages.sublist(0, _messages.length - 1),
      userPrompt: trimmed,
      systemInstruction: sysInstruction,
    )) {
      finalResponse = partial;
      if (mounted) {
        setState(() {
          assistantMsg.content = partial;
        });
      }
    }

    if (mounted) {
      setState(() => _auraState = JarvisAuraState.standbyIdle);
      if (speakReply || _operationalMode == JarvisOperationalMode.jarvisVoiceHud) {
        await _voiceService.speak(finalResponse);
      }
    }
  }

  Future<void> _triggerSelfEvolve() async {
    setState(() => _auraState = JarvisAuraState.computingThinking);
    _voiceService.speak('Initiating Hermes self-evolution synthesis, ${widget.settings.operatorTitle}.');
    final recent = _messages.reversed.take(8).map((m) => '${m.role}: ${m.content}').toList();
    final summary = await widget.hermesService.selfEvolveFromConversation(
      aiService: _aiService,
      recentTranscript: recent,
    );
    if (mounted) {
      setState(() {
        _auraState = JarvisAuraState.standbyIdle;
        _messages.add(ChatMessage(
          id: _uuid.v4(),
          role: 'assistant',
          content: '🧬 **Hermes Self-Evolution Complete:**\n$summary',
        ));
      });
      _voiceService.speak(summary);
    }
  }

  Future<void> _toggleSentryMode(bool arm) async {
    await _bridge.setSentryMode(arm);
    setState(() {
      _sentryArmed = arm;
      _auraState = arm ? JarvisAuraState.tacticalLockdown : JarvisAuraState.standbyIdle;
    });
    _voiceService.speak(
      arm
          ? 'Sentry protocol armed, ${widget.settings.operatorTitle}. Accelerometer watchdog active.'
          : 'Sentry protocol disarmed. Returning to nominal standby.',
    );
  }

  void _openCodeBlack() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CodeBlackScreen(bridge: _bridge, voiceService: _voiceService),
      ),
    );
  }

  void _openDangerSuite() {
    setState(() => _auraState = JarvisAuraState.tacticalLockdown);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DangerSuiteScreen(
          bridge: _bridge,
          voiceService: _voiceService,
          telegramService: _telegramService,
        ),
      ),
    ).then((_) {
      if (mounted && !_sentryArmed) {
        setState(() => _auraState = JarvisAuraState.standbyIdle);
      }
    });
  }

  void _openApiSettings() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SettingsApiScreen(
          settings: widget.settings,
          hermesService: widget.hermesService,
          aiService: _aiService,
          telegramService: _telegramService,
          onSettingsSaved: () {
            setState(() {
              _alwaysOnListening = widget.settings.alwaysOnWakeWord;
              _voiceService.alwaysOnMode = _alwaysOnListening;
              _voiceService.updateVoiceConfig(
                locale: widget.settings.voiceLocale,
                rate: widget.settings.speechRate,
                pitch: widget.settings.speechPitch,
              );
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auraColor = _auraState.color;
    return Scaffold(
      backgroundColor: const Color(0xFF050A14),
      drawer: _buildStarkDrawer(auraColor),
      appBar: AppBar(
        backgroundColor: const Color(0xFF081121),
        elevation: 0,
        title: Row(
          children: [
            Icon(Icons.bolt, color: auraColor, size: 20),
            const SizedBox(width: 6),
            const Text(
              'J.A.R.V.I.S.',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.2,
                fontSize: 16,
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: auraColor.withOpacity(0.16),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: auraColor.withOpacity(0.5)),
              ),
              child: Text(
                widget.settings.geminiModel.toUpperCase(),
                style: TextStyle(color: auraColor, fontSize: 9, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        actions: [
          // Live HUD Projection Switcher Pill (Arc Reactor vs Suit Bust)
          IconButton(
            tooltip: 'Switch 3D Hologram Projection',
            icon: Icon(
              _projectionStyle == HudProjectionStyle.arcReactorCore
                  ? Icons.blur_circular
                  : Icons.person_outline,
              color: auraColor,
            ),
            onPressed: () {
              setState(() {
                _projectionStyle = _projectionStyle == HudProjectionStyle.arcReactorCore
                    ? HudProjectionStyle.hologramSuitBust
                    : HudProjectionStyle.arcReactorCore;
              });
            },
          ),
          // Multi-Place API Settings Button
          IconButton(
            tooltip: 'Configure API Keys & Hermes Memory',
            icon: const Icon(Icons.settings_suggest, color: Color(0xFF00E5FF)),
            onPressed: _openApiSettings,
          ),
        ],
      ),
      body: Column(
        children: [
          // Operational Mode Selector Bar (J.A.R.V.I.S. HUD | Agent Mode | Chat Mode)
          _buildModeSelectorBar(auraColor),

          // API Key Banner if not yet added in Settings
          if (!widget.settings.hasGeminiKey)
            GestureDetector(
              onTap: _openApiSettings,
              child: Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFB300).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFFFB300)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.vpn_key, color: Color(0xFFFFB300), size: 18),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Tap here to enter your Google Gemini API Key (and optional secondary APIs) in Settings.',
                        style: TextStyle(color: Color(0xFFFFB300), fontSize: 11.5, fontWeight: FontWeight.w600),
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios, color: Color(0xFFFFB300), size: 13),
                  ],
                ),
              ),
            ),

          // Main Content Body for the 3 Operational Modes
          Expanded(
            child: switch (_operationalMode) {
              JarvisOperationalMode.jarvisVoiceHud => _buildJarvisVoiceHudView(auraColor),
              JarvisOperationalMode.autonomousAgent => _buildAutonomousAgentView(auraColor),
              JarvisOperationalMode.streamingChat => _buildStreamingChatView(auraColor),
            },
          ),

          // Bottom Prompt & Voice Dock
          _buildBottomCommandDock(auraColor),
        ],
      ),
    );
  }

  Widget _buildModeSelectorBar(Color auraColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: const Color(0xFF081121),
      child: Row(
        children: [
          _modeTabButton(
            mode: JarvisOperationalMode.jarvisVoiceHud,
            icon: Icons.graphic_eq,
            label: 'J.A.R.V.I.S. HUD',
            auraColor: auraColor,
          ),
          const SizedBox(width: 8),
          _modeTabButton(
            mode: JarvisOperationalMode.autonomousAgent,
            icon: Icons.smart_toy_outlined,
            label: 'AGENT MODE',
            auraColor: auraColor,
          ),
          const SizedBox(width: 8),
          _modeTabButton(
            mode: JarvisOperationalMode.streamingChat,
            icon: Icons.chat_bubble_outline,
            label: 'CHAT MODE',
            auraColor: auraColor,
          ),
        ],
      ),
    );
  }

  Widget _modeTabButton({
    required JarvisOperationalMode mode,
    required IconData icon,
    required String label,
    required Color auraColor,
  }) {
    final active = _operationalMode == mode;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _operationalMode = mode),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            color: active ? auraColor.withOpacity(0.2) : const Color(0xFF0D192E),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: active ? auraColor : Colors.white12,
              width: active ? 1.4 : 1.0,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 15, color: active ? auraColor : Colors.white60),
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(
                  color: active ? auraColor : Colors.white70,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Mode 1: J.A.R.V.I.S. Hands-Free Voice & 3D Cyber HUD
  Widget _buildJarvisVoiceHudView(Color auraColor) {
    final latestAssistant = _messages.lastWhere(
      (m) => m.role == 'assistant',
      orElse: () => ChatMessage(id: '0', role: 'assistant', content: 'Standing by, Sir.'),
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        children: [
          // Top Quick-Action Pods (Always-On Mic, Self Evolve, Air Gestures, Sentry)
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _hudActionPod(
                icon: Icons.hearing,
                label: _alwaysOnListening ? 'ALWAYS-ON: ACTIVE' : 'ALWAYS-ON: STANDBY',
                active: _alwaysOnListening,
                activeColor: const Color(0xFF00E676),
                onTap: () {
                  setState(() {
                    _alwaysOnListening = !_alwaysOnListening;
                    _voiceService.alwaysOnMode = _alwaysOnListening;
                  });
                  if (_alwaysOnListening) {
                    _voiceService.startListening();
                  } else {
                    _voiceService.stopListening();
                  }
                },
              ),
              _hudActionPod(
                icon: Icons.auto_awesome,
                label: 'SELF EVOLVE',
                active: false,
                activeColor: const Color(0xFFBA68C8),
                onTap: _triggerSelfEvolve,
              ),
              _hudActionPod(
                icon: Icons.pan_tool_alt_outlined,
                label: 'AIR GESTURES',
                active: _airGesturesEnabled,
                activeColor: const Color(0xFF00E5FF),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (_) => AirGesturesModal(
                      bridge: _bridge,
                      initialEnabled: _airGesturesEnabled,
                      onChanged: (v) => setState(() => _airGesturesEnabled = v),
                    ),
                  );
                },
              ),
              _hudActionPod(
                icon: Icons.shield_outlined,
                label: _sentryArmed ? 'SENTRY: ARMED' : 'SENTRY MODE',
                active: _sentryArmed,
                activeColor: const Color(0xFFFF1744),
                onTap: () => _toggleSentryMode(!_sentryArmed),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Dual 3D Hologram Projection Core
          DualHologramHudWidget(
            auraState: _auraState,
            projectionStyle: _projectionStyle,
            soundLevel: _soundLevel,
            onCoreTapped: () {
              if (_voiceService.isListening) {
                _voiceService.stopListening();
                setState(() => _auraState = JarvisAuraState.standbyIdle);
              } else {
                setState(() => _auraState = JarvisAuraState.activeListening);
                _voiceService.startListening();
              }
            },
          ),
          const SizedBox(height: 14),

          // Live Vocal Telemetry Readout Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF0B1528).withOpacity(0.9),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: auraColor.withOpacity(0.45)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'NEURAL TELEMETRY FEED',
                      style: TextStyle(
                        color: auraColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      _projectionStyle == HudProjectionStyle.arcReactorCore
                          ? 'PROJECTION: ARC REACTOR CORE'
                          : 'PROJECTION: HOLOGRAM SUIT BUST',
                      style: const TextStyle(color: Colors.white54, fontSize: 10),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                MarkdownBody(
                  data: latestAssistant.content,
                  styleSheet: MarkdownStyleSheet(
                    p: const TextStyle(color: Colors.white, fontSize: 13.5, height: 1.45),
                    strong: TextStyle(color: auraColor, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Quick Superpower Launch Bar
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _superpowerPill(
                  '🧠 Brain Dump',
                  () => showDialog(
                    context: context,
                    builder: (_) => BrainDumpDialog(
                      taskExecutor: _taskExecutor,
                      voiceService: _voiceService,
                    ),
                  ),
                ),
                _superpowerPill(
                  '👁️ Optical Solver',
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => OpticalSolverScreen(
                        aiService: _aiService,
                        voiceService: _voiceService,
                      ),
                    ),
                  ),
                ),
                _superpowerPill(
                  '📡 Airspace Radar',
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AirspaceRadarScreen(voiceService: _voiceService),
                    ),
                  ),
                ),
                _superpowerPill(
                  '🌐 Polyglot Translator',
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PolyglotDiplomatScreen(
                        aiService: _aiService,
                        voiceService: _voiceService,
                      ),
                    ),
                  ),
                ),
                _superpowerPill('☠️ Danger Suite (5)', _openDangerSuite),
                _superpowerPill('🎭 Code Black', _openCodeBlack),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Mode 2: Autonomous UI Agent (Observe -> Think -> Act Loop)
  Widget _buildAutonomousAgentView(Color auraColor) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF0C172B),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: auraColor.withOpacity(0.5)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '🤖 OBSERVE → THINK → ACT UI ENGINE',
                      style: TextStyle(
                        color: Color(0xFF00E5FF),
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => _bridge.openAccessibilitySettings(),
                      icon: const Icon(Icons.accessibility_new, size: 16, color: Color(0xFF00E676)),
                      label: const Text(
                        'ENABLE SERVICE',
                        style: TextStyle(color: Color(0xFF00E676), fontSize: 11),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _agentGoalCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  decoration: InputDecoration(
                    labelText: 'Autonomous Device Goal',
                    labelStyle: const TextStyle(color: Colors.white70),
                    filled: true,
                    fillColor: const Color(0xFF060C18),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00E5FF),
                          foregroundColor: Colors.black,
                        ),
                        onPressed: _taskExecutor.isAgentRunning
                            ? null
                            : () async {
                                setState(() {
                                  _agentLogs.clear();
                                  _auraState = JarvisAuraState.computingThinking;
                                });
                                await _taskExecutor.runAutonomousUiGoal(
                                  goal: _agentGoalCtrl.text.trim(),
                                  onStepLog: (log) {
                                    if (mounted) setState(() => _agentLogs.add(log));
                                  },
                                );
                                if (mounted) {
                                  setState(() => _auraState = JarvisAuraState.standbyIdle);
                                }
                              },
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('DISPATCH UI AGENT'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFFFF1744),
                        side: const BorderSide(color: Color(0xFFFF1744)),
                      ),
                      onPressed: () {
                        _taskExecutor.cancelAgent();
                        setState(() => _auraState = JarvisAuraState.standbyIdle);
                      },
                      icon: const Icon(Icons.stop),
                      label: const Text('STOP'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF070E1B),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white12),
              ),
              child: _agentLogs.isEmpty
                  ? const Center(
                      child: Text(
                        'Agent execution telemetry logs will stream here...',
                        style: TextStyle(color: Colors.white38, fontSize: 12),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _agentLogs.length,
                      itemBuilder: (context, idx) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(
                          _agentLogs[idx],
                          style: const TextStyle(
                            color: Color(0xFF00E676),
                            fontFamily: 'monospace',
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  /// Mode 3: High-Speed Conversational Streaming Chat Mode
  Widget _buildStreamingChatView(Color auraColor) {
    return ListView.builder(
      padding: const EdgeInsets.all(14),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final m = _messages[index];
        final isUser = m.role == 'user';
        return Align(
          alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isUser ? const Color(0xFF12284A) : const Color(0xFF0B1528),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isUser ? const Color(0xFF00E5FF) : auraColor.withOpacity(0.45),
              ),
            ),
            child: MarkdownBody(
              data: m.content,
              styleSheet: MarkdownStyleSheet(
                p: const TextStyle(color: Colors.white, fontSize: 13.5, height: 1.4),
                code: const TextStyle(
                  color: Color(0xFF00E676),
                  backgroundColor: Colors.black54,
                  fontFamily: 'monospace',
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBottomCommandDock(Color auraColor) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: const Color(0xFF081121),
        border: Border(top: BorderSide(color: auraColor.withOpacity(0.3))),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                if (_voiceService.isListening) {
                  _voiceService.stopListening();
                  setState(() => _auraState = JarvisAuraState.standbyIdle);
                } else {
                  setState(() => _auraState = JarvisAuraState.activeListening);
                  _voiceService.startListening();
                }
              },
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _voiceService.isListening
                      ? const Color(0xFF00E676).withOpacity(0.25)
                      : auraColor.withOpacity(0.15),
                  border: Border.all(
                    color: _voiceService.isListening ? const Color(0xFF00E676) : auraColor,
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  _voiceService.isListening ? Icons.mic : Icons.mic_none,
                  color: _voiceService.isListening ? const Color(0xFF00E676) : auraColor,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _promptCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13.5),
                onSubmitted: (val) => _sendPrompt(val),
                decoration: InputDecoration(
                  hintText: 'Command J.A.R.V.I.S. or ask Gemini...',
                  hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                  filled: true,
                  fillColor: const Color(0xFF0D192E),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: () => _sendPrompt(_promptCtrl.text),
              icon: Icon(Icons.send_rounded, color: auraColor),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hudActionPod({
    required IconData icon,
    required String label,
    required bool active,
    required Color activeColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
        decoration: BoxDecoration(
          color: active ? activeColor.withOpacity(0.22) : const Color(0xFF0C172B),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? activeColor : Colors.white24),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: active ? activeColor : Colors.white70),
            const SizedBox(width: 5),
            Text(
              label,
              style: TextStyle(
                color: active ? activeColor : Colors.white70,
                fontSize: 10.5,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _superpowerPill(String title, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ActionChip(
        backgroundColor: const Color(0xFF0E1C36),
        side: const BorderSide(color: Color(0xFF00E5FF), width: 0.8),
        label: Text(
          title,
          style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w600),
        ),
        onPressed: onTap,
      ),
    );
  }

  Widget _buildStarkDrawer(Color auraColor) {
    return Drawer(
      backgroundColor: const Color(0xFF070E1B),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              color: Color(0xFF0C182E),
              border: Border(bottom: BorderSide(color: Color(0xFF00E5FF))),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Text(
                  '⚡ J.A.R.V.I.S. STARK SUITE',
                  style: TextStyle(
                    color: Color(0xFF00E5FF),
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Gemini Core • 9 Superpowers • Hermes v1.1.0',
                  style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12),
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.vpn_key, color: Color(0xFF00E676)),
            title: const Text('Multi-Place API Keys & Settings', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            subtitle: const Text('Gemini, OpenRouter, Ollama, Telegram, Voice', style: TextStyle(color: Colors.white54, fontSize: 11)),
            onTap: () {
              Navigator.pop(context);
              _openApiSettings();
            },
          ),
          ListTile(
            leading: const Icon(Icons.dangerous, color: Color(0xFFFF1744)),
            title: const Text('☠️ STARK DANGER SUITE (5 MODULES)', style: TextStyle(color: Color(0xFFFF1744), fontWeight: FontWeight.bold)),
            subtitle: const Text('Omega Self-Destruct, Red Alert Strobe, Ghost Trap, Ultron, Overdrive', style: TextStyle(color: Colors.white70, fontSize: 11)),
            onTap: () {
              Navigator.pop(context);
              _openDangerSuite();
            },
          ),
          const Divider(color: Colors.white24),
          _drawerTile(
            icon: Icons.pan_tool_alt_outlined,
            title: '1. Iron Man Air Gestures',
            subtitle: 'Zero-touch proximity sensor controls',
            onTap: () {
              Navigator.pop(context);
              showDialog(
                context: context,
                builder: (_) => AirGesturesModal(
                  bridge: _bridge,
                  initialEnabled: _airGesturesEnabled,
                  onChanged: (v) => setState(() => _airGesturesEnabled = v),
                ),
              );
            },
          ),
          _drawerTile(
            icon: Icons.bolt,
            title: '2. Arc Reactor Charging Telemetry',
            subtitle: 'Live Wattage, Voltage & Thermal HUD',
            onTap: () async {
              Navigator.pop(context);
              final telemetry = await _bridge.getBatteryTelemetry();
              if (mounted) {
                showDialog(
                  context: context,
                  builder: (_) => ArcReactorTelemetryDialog(telemetry: telemetry),
                );
              }
            },
          ),
          _drawerTile(
            icon: Icons.translate,
            title: '3. Polyglot Diplomat',
            subtitle: '14+ language two-way voice translator',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PolyglotDiplomatScreen(
                    aiService: _aiService,
                    voiceService: _voiceService,
                  ),
                ),
              );
            },
          ),
          _drawerTile(
            icon: Icons.warning_amber_rounded,
            title: '4. "Code Black" Lockout',
            subtitle: 'Simulated kernel panic anti-snooping screen',
            onTap: () {
              Navigator.pop(context);
              _openCodeBlack();
            },
          ),
          _drawerTile(
            icon: Icons.bubble_chart_outlined,
            title: '5. Holographic Floating Co-Pilot',
            subtitle: 'Universal on-screen context & reply triage',
            onTap: () {
              Navigator.pop(context);
              showDialog(
                context: context,
                builder: (_) => FloatingCoPilotModal(
                  bridge: _bridge,
                  aiService: _aiService,
                  voiceService: _voiceService,
                ),
              );
            },
          ),
          _drawerTile(
            icon: Icons.radar,
            title: '6. Overhead Airspace & ISS Radar',
            subtitle: 'Live OpenSky ADS-B flights & orbital pass',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AirspaceRadarScreen(voiceService: _voiceService),
                ),
              );
            },
          ),
          _drawerTile(
            icon: Icons.hub_outlined,
            title: '7. Chaotic Brain Dump Decoupler',
            subtitle: 'Parallel multi-task voice disassembly',
            onTap: () {
              Navigator.pop(context);
              showDialog(
                context: context,
                builder: (_) => BrainDumpDialog(
                  taskExecutor: _taskExecutor,
                  voiceService: _voiceService,
                ),
              );
            },
          ),
          _drawerTile(
            icon: Icons.center_focus_strong,
            title: '8. Real-Time Optical HUD Solver',
            subtitle: 'Gemini Vision AR for Math, Code, Bills & PCB',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OpticalSolverScreen(
                    aiService: _aiService,
                    voiceService: _voiceService,
                  ),
                ),
              );
            },
          ),
          _drawerTile(
            icon: Icons.security,
            title: '9. Stark Network Security Audit',
            subtitle: 'Subnet sweep & critical port scanner',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => NetworkAuditScreen(voiceService: _voiceService),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _drawerTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFF00E5FF)),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
      onTap: onTap,
    );
  }
}
